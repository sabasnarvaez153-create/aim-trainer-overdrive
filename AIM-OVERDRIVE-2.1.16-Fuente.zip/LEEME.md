# AIM OVERDRIVE 2.1.16

Actualización enfocada en entrenamientos claros, creación de rutas propias y ajustes para PC de bajos recursos.

## Novedades

- Se retiraron varias variantes repetidas de tracking. Se conservan las rutas horizontal, vertical, diagonal, circular, reactiva, multobjetivo, cambio de objetivo y las rutas lineales X, Y, diagonal y ángulo variable.
- El tracking diagonal rebota en cada borde y cambia la dirección del eje que tocó el límite.
- Se eliminó por completo el entrenamiento de supervivencia 3D.
- La píldora del entrenamiento 3D ahora se muestra vertical.
- La mira dibujada aparece sobre el campo 3D y sigue el centro cuando la cámara captura el ratón.
- El selector durante la partida agrupa los ejercicios en Flick, Tracking y Retos/Combinados.
- Los récords se pueden borrar al mantener **X** sobre su tarjeta. Una barra muestra el avance; también se mantienen las opciones para limpiar todo.
- Se puede exportar el historial de récords a JSON e importarlo después.
- Creador de entrenamientos Flick y Tracking: elige el nombre y duración, graba arrastrando el objetivo por el campo y guarda la ruta. El entrenador la repite con inicios, direcciones y velocidades variadas.
- Nuevo modo de bajos recursos en Ajustes: baja la resolución interna del campo para aliviar la carga. El juego conserva un límite de 60 FPS mientras se entrena; el rendimiento real depende del equipo.

## Abrir el proyecto

1. Instala Node.js LTS.
2. En esta carpeta ejecuta `npm install`.
3. Ejecuta `npm start` para abrir el entrenador desde el código.
4. Ejecuta `npm run dist` para generar el instalador de Windows x64.

Los récords, rutas creadas y ajustes se guardan localmente en el equipo.
