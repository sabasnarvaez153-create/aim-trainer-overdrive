/* AIM OVERDRIVE 2.1.7 — full-window monochrome interface and responsive controls. */
(()=>{
 'use strict';
 const $=s=>document.querySelector(s), body=document.body;
 const mark='AO';
 if(!['house','empty'].includes(cfg.arena3d)){cfg.arena3d='house';if(typeof sync==='function')sync();if(typeof save==='function')save()}
 $('#arena3d')?.querySelectorAll('option').forEach(option=>{if(!['house','empty'].includes(option.value))option.remove()});

 // Suppress the previous branded intro and its optional community popups.
 try{sessionStorage.setItem('aoInvitesSeen','1')}catch{}
 $('#skipIntro')?.click();
 $('#dsyIntro')?.remove();
 const intro=$('#bootIntro');
 if(intro)setTimeout(()=>{intro.classList.add('is-leaving');setTimeout(()=>intro.remove(),720)},5200);

 document.documentElement.lang='es';
 try{localStorage.setItem('aoInterface','standard')}catch{}
 if(typeof setInterface==='function')setInterface('standard');
 if(typeof setLanguage==='function')setLanguage('es');

 // Replace every visible legacy wordmark with the symbol mark and product name.
 document.querySelectorAll('.brand,.welcome-brand').forEach(host=>{
  host.classList.remove('logo-host');
  host.querySelector('img.dsy-logo')?.remove();
  let b=host.querySelector('b');if(!b){b=document.createElement('b');host.prepend(b)}b.className='classic-mark';b.textContent=mark;
  let span=host.querySelector('span');if(!span){span=document.createElement('span');host.append(span)}span.innerHTML='AIM OVERDRIVE<small>PRECISION TRAINING</small>';
 });
 const title=document.querySelector('title');if(title)title.textContent='AIM OVERDRIVE — Precision Training';
 const live=$('.live');if(live)live.innerHTML='CAMPO DE ENTRENAMIENTO / <i id="topMode">HORIZONTAL</i>';
 const fs=$('#fullscreenBtn');if(fs){fs.textContent='⛶';fs.title='Pantalla completa'}

 // The home remains the only library screen; group the existing drills into three useful columns.
 const cards=$('#exerciseCards');
 function groupCards(){
  if(!cards)return;
  const all=[...cards.querySelectorAll(':scope > .exercise-card')];
  if(!all.length)return;
  const groups=[
   {key:'precision',title:'PRECISIÓN / FLICK',color:'var(--classic-cyan)',items:[]},
   {key:'tracking',title:'TRACKING',color:'var(--classic-amber)',items:[]},
   {key:'challenge',title:'RETOS / COMBINADOS',color:'var(--classic-pink)',items:[]}
  ];
  for(const card of all){
   const key=card.dataset.key||'';
   const group=key.startsWith('combo-')||key.startsWith('life-track')?'challenge':key.startsWith('flick-')?'precision':'tracking';
   const entry=groups.find(g=>g.key===group);
   const modeInfo=typeof modes!=='undefined'&&modes.find(m=>m[0]===key);
   if(modeInfo)card.title=modeInfo[3];
   entry.items.push(card);
  }
  cards.replaceChildren();
  const columns=document.createElement('div');columns.className='classic-training-groups';
  for(const group of groups){
   const section=document.createElement('section');section.className='classic-training-group';section.style.setProperty('--group-accent',group.color);
   const heading=document.createElement('h3');heading.textContent=group.title;
   const count=document.createElement('span');count.textContent=String(group.items.length).padStart(2,'0');heading.append(count);
    const list=document.createElement('div');list.className='classic-training-list';group.items.forEach((card,index)=>{card.style.setProperty('--tile-order',index);list.append(card)});
   section.append(heading,list);columns.append(section);
  }
  cards.append(columns);
 }
 const originalRender=window.renderWelcome;
 if(originalRender){window.renderWelcome=function(){const result=originalRender.apply(this,arguments);groupCards();return result}}

 // Move Glory and saved scores into the home page so only the arena and its settings remain in-session.
 const welcome=$('#welcome'), welcomeInner=$('.welcome-inner'),homeCopy=$('.welcome-copy');
 if(welcomeInner&&homeCopy){
  const credits=document.createElement('div');credits.className='creator-credits';credits.innerHTML='<span>CRÉDITOS</span><b>xBL41Sx · 016 · shadow · purpled</b>';homeCopy.append(credits);
  let data=$('.welcome-player-data');
  if(!data){data=document.createElement('div');data.className='welcome-player-data';homeCopy.after(data)}
  const panelHost=$('.player-panels');
  if(panelHost){panelHost.querySelectorAll('.glory-panel,.saved-score-panel').forEach(panel=>data.append(panel));panelHost.remove()}
  const rank=$('#dsyHomeRank');if(rank)data.append(rank);
  const profiles=document.createElement('section');profiles.className='roblox-profiles';profiles.innerHTML='<div class="roblox-profiles-heading"><small>PERFILES DE ROBLOX</small><span>CREADORES</span></div><div class="roblox-profile-list"><a href="https://www.roblox.com/es/users/1635133689/profile" target="_blank" rel="noopener noreferrer"><b>xBL41Sx</b><span>ABRIR PERFIL ↗</span></a><a href="https://www.roblox.com/es/users/2221535493/profile" target="_blank" rel="noopener noreferrer"><b>shadow</b><span>ABRIR PERFIL ↗</span></a><a href="https://www.roblox.com/es/users/7516908034/profile" target="_blank" rel="noopener noreferrer"><b>purpled</b><span>ABRIR PERFIL ↗</span></a><a href="https://www.roblox.com/es/users/1012028559/profile" target="_blank" rel="noopener noreferrer"><b>016</b><span>ABRIR PERFIL ↗</span></a></div>';
  data.append(profiles);

 }

 // Replace the old home dock to detach theme switching and keep just the requested destinations.
 const oldDock=$('.home-dock');
 if(oldDock){
  const dock=oldDock.cloneNode(false);dock.setAttribute('aria-label','Menú principal');
  dock.innerHTML='<button data-home-action="training"><i>◎</i><span>ENTRENAR</span></button><button data-home-action="records"><i>▤</i><span>RÉCORDS</span></button><button data-home-action="settings"><i>⚙</i><span>AJUSTES</span></button>';
  oldDock.replaceWith(dock);
  dock.addEventListener('click',e=>{
   const button=e.target.closest('[data-home-action]');if(!button)return;
   const action=button.dataset.homeAction;
   if(action==='training')$('.welcome-exercises')?.scrollIntoView({behavior:'smooth',block:'start'});
   if(action==='records')$('.welcome-records')?.scrollIntoView({behavior:'smooth',block:'center'});
   if(action==='settings')openSettings();
  });
 }

 // Put all exercise controls in a modal with a live target and hitbox preview.
 const editor=$('#editorDeck'),viewSwitch=$('.range-view-switch'),customizer=$('.range-customizer'),center=$('.center'),range=$('.range'),stats=$('.stats');
 const reticleControls=document.createElement('section');reticleControls.id='reticleControls';reticleControls.className='reticle-controls';reticleControls.innerHTML='<div class="reticle-editor-heading"><b>EDITOR DE MIRA 3D</b><small>CAMBIA Y PREVISUALIZA AL INSTANTE</small></div><label>FORMA <select id="reticleStyle"><option value="cross">Cruz abierta</option><option value="dot">Punto</option><option value="ring">Anillo</option><option value="cross-dot">Cruz con punto</option><option value="circle">Círculo con punto</option><option value="square">Cuadro</option><option value="hollow-square">Cuadro abierto</option><option value="diamond">Diamante</option><option value="x">Equis</option><option value="triangle">Triángulo</option><option value="bracket">Esquinas</option><option value="burst">Estallido</option><option value="chevron">Chevron</option><option value="plus">Más</option><option value="circle-cross">Anillo con cruz</option><option value="t">Mira en T</option><option value="four-dots">Cuatro puntos</option><option value="hexagon">Hexágono</option><option value="slash">Diagonal</option><option value="star">Estrella</option><option value="ring-ticks">Anillo graduado</option><option value="double-ring">Doble anillo</option></select></label><div class="field">LONGITUD <b id="reticleLengthValue">14</b> px</div><input id="reticleLength" type="range" min="4" max="40" value="14"><div class="field">GROSOR <b id="reticleThicknessValue">2</b> px</div><input id="reticleThickness" type="range" min="1" max="8" value="2"><div class="field">SEPARACIÓN <b id="reticleGapValue">4</b> px</div><input id="reticleGap" type="range" min="0" max="20" value="4"><div class="field">ROTACIÓN <b id="reticleRotationValue">0</b>°</div><input id="reticleRotation" type="range" min="0" max="360" value="0"><label class="reticle-color-field">COLOR DE MIRA <input id="reticleColor" type="color" value="#ffffff"></label><div class="field">TAMAÑO GENERAL <b id="reticleSizeValue">36</b> px</div><input id="reticleSize" type="range" min="12" max="120" value="36"><label>IMAGEN PERSONALIZADA <input id="reticleImageFile" type="file" accept="image/png,image/webp,image/jpeg,image/gif"></label><button type="button" id="reticleImageClear" class="reset">USAR MIRA DIBUJADA</button><small class="reticle-note">Los controles actualizan esta mira y la del centro al usar la cámara 3D.</small><div class="reticle-preview-row"><small>VISTA PREVIA EN VIVO</small><span id="reticlePreview" class="camera-center-dot preview-reticle" aria-hidden="true"></span></div></section>';

 if(editor)editor.insertBefore(reticleControls,$('#sensConverterBtn'));
 const flickKeyControls=document.createElement('section');flickKeyControls.id='flickKeyControls';flickKeyControls.className='flick-key-controls';flickKeyControls.innerHTML='<label for="flickKeySequence">COMBINACIÓN DE TECLAS · FLICK</label><input id="flickKeySequence" type="text" maxlength="4" inputmode="text" autocomplete="off" spellcheck="false" placeholder="VACÍO = CLIC NORMAL"><small>Escribe de 1 a 4 letras o números. Mantén el cursor sobre un objetivo y presiona la secuencia para acertar.</small>';
 if(editor)editor.insertBefore(flickKeyControls,$('#sensConverterBtn'));
 const flickKeysInput=$('#flickKeySequence');if(flickKeysInput){flickKeysInput.value=String(cfg.flickKeys||'').toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,4);flickKeysInput.addEventListener('input',()=>{const value=flickKeysInput.value.toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,4);flickKeysInput.value=value;cfg.flickKeys=value;if(typeof save==='function')save()})}
 if(center&&stats&&range)center.insertBefore(stats,range);
 if(center&&viewSwitch&&range)center.insertBefore(viewSwitch,range);
 const settingsModal=document.createElement('div');settingsModal.id='settingsModal';settingsModal.className='settings-modal';
 settingsModal.innerHTML='<section class="settings-dialog" role="dialog" aria-modal="true" aria-labelledby="settingsTitle"><header class="settings-dialog-head"><div><small>PERSONALIZA TU SESIÓN</small><h2 id="settingsTitle">Ajustes del entrenamiento</h2></div><button type="button" class="settings-close" aria-label="Cerrar">×</button></header><div class="settings-dialog-layout"><div class="settings-controls"></div><aside class="settings-preview"><div class="settings-preview-head"><div><small>VISTA PREVIA</small><h3>Objetivo e hitbox</h3></div><span>EN VIVO</span></div><p class="preview-help">El borde discontinuo representa el área que cuenta como impacto.</p><div class="preview-stage"><div id="previewHitbox" class="preview-hitbox"><div id="previewTarget" class="preview-target"></div></div><span class="preview-cross">+</span></div><div class="preview-readouts"><div><small>TAMAÑO</small><b id="previewSize">42 px</b></div><div><small>HITBOX</small><b id="previewHitSize">96 × 96 px</b></div><div><small>ESTILO</small><b id="previewStyle">Simple</b></div></div></aside></div><footer class="settings-dialog-actions"><button type="button" class="settings-cancel">Cancelar</button><button type="button" class="settings-accept">Aceptar y reiniciar</button></footer></section>';
 const controls=settingsModal.querySelector('.settings-controls');
 [customizer,editor].forEach(node=>{if(node)controls.append(node)});
 const performanceCard=document.createElement('label');performanceCard.className='low-resource-option';performanceCard.innerHTML='<input type="checkbox" id="lowResourceMode"><span><b>MODO PC DE BAJOS RECURSOS</b><small>Reduce la resolución interna del escenario para aliviar la carga gráfica. Mantiene el límite de 60 FPS.</small></span>';
 controls.append(performanceCard);
 const performanceToggle=performanceCard.querySelector('#lowResourceMode');
 performanceToggle.checked=localStorage.getItem('aoLowResource')==='1';
 performanceToggle.addEventListener('change',()=>{localStorage.setItem('aoLowResource',performanceToggle.checked?'1':'0');window.resize?.();window.frame?.(performance.now())});
 editor?.classList.remove('dsy-folded');editor?.querySelectorAll(':scope > .dsy-fold-toggle').forEach(node=>node.remove());
 try{localStorage.setItem('dsy207-fold-LOADOUT / SETTINGS','0')}catch{}
 document.body.append(settingsModal);
 let settingsSnapshot=null,settingsWasActive=false,settingsWasPaused=false,settingsHadPointerLock=false;
 function updateSettingsPreview(){
  const number=(id,fallback)=>Number($('#'+id)?.value??fallback);
  const size=number('size',42),width=number('targetWidth',100),height=number('targetThickness',100),hit=number('hitbox',100),hitWidth=number('hitboxWidth',100),hitHeight=number('hitboxThickness',100);
  const style=$('#targetType')?.value||'simple',color=$('#targetColor')?.value||'#c3c3c3',ring=number('ringThickness',18);
  const targetW=Math.max(12,Math.min(190,size*width/100)),targetH=Math.max(12,Math.min(180,size*height/100));
  const boxW=Math.max(24,Math.min(220,targetW*hit/100*hitWidth/100)),boxH=Math.max(24,Math.min(200,targetH*hit/100*hitHeight/100));
  const target=$('#previewTarget'),box=$('#previewHitbox'),stage=$('.preview-stage');if(!target||!box)return;
  target.className='preview-target'+(style==='ring'?' is-ring':'');
  target.style.setProperty('--target-color',color);target.style.width=targetW+'px';target.style.height=targetH+'px';
  target.innerHTML='';
  target.style.border=style==='ring'?Math.max(1.5,Math.min(targetW,targetH)*.5*ring/100)+'px solid '+color:'0';
  target.style.background=style==='simple'?color:'transparent';
  box.style.width=boxW+'px';box.style.height=boxH+'px';box.style.setProperty('--target-color',color);
  stage?.style.setProperty('--scene-color',$('#sceneColor')?.value||'#999999');
  $('#previewSize').textContent=Math.round(targetW)+' × '+Math.round(targetH)+' px';$('#previewHitSize').textContent=Math.round(boxW)+' × '+Math.round(boxH)+' px';
  $('#previewStyle').textContent=style==='ring'?'Anillo':'Simple';
 }
 function openSettings(){
  if(settingsModal.classList.contains('open'))return;
  settingsSnapshot=JSON.parse(JSON.stringify(cfg));settingsWasActive=!!running&&!paused;settingsWasPaused=!!running&&!!paused;settingsHadPointerLock=!!canvas&&document.pointerLockElement===canvas;if(settingsHadPointerLock)document.exitPointerLock?.();
  if(settingsWasActive)pause();
  updateSettingsPreview();settingsModal.classList.add('open');body.classList.add('settings-modal-open');
 }
 function closeSettings(accept){
  if(!settingsModal.classList.contains('open'))return;
  if(accept){
   if(typeof read==='function')read();if(typeof reset==='function')reset();
   if(settingsWasActive||settingsWasPaused){if(typeof start==='function')start()}
  }else if(settingsSnapshot){
   cfg=Object.assign({},settingsSnapshot);if(flickKeysInput)flickKeysInput.value=cfg.flickKeys||'';if(typeof sync==='function')sync();if(typeof createSessionTargets==='function')targets=createSessionTargets();if(typeof resize==='function')resize();if(typeof save==='function')save();
   if(settingsWasActive&&running&&paused&&typeof pause==='function')pause();
  }
  settingsModal.classList.remove('open');body.classList.remove('settings-modal-open');settingsSnapshot=null;settingsWasActive=settingsWasPaused=false;if(settingsHadPointerLock&&cfg.depth3d){settingsHadPointerLock=false;requestCameraLock()}else settingsHadPointerLock=false;
 }
 settingsModal.querySelector('.settings-close').addEventListener('click',()=>closeSettings(false));
 settingsModal.querySelector('.settings-cancel').addEventListener('click',()=>closeSettings(false));
 settingsModal.querySelector('.settings-accept').addEventListener('click',()=>closeSettings(true));
 settingsModal.addEventListener('mousedown',e=>{if(e.target===settingsModal)closeSettings(false)});
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&settingsModal.classList.contains('open')){e.preventDefault();closeSettings(false)}});
 controls.addEventListener('input',updateSettingsPreview);controls.addEventListener('change',updateSettingsPreview);

 // Switch drills from a searchable-style in-game picker without returning home.
 const picker=document.createElement('div');picker.id='trainingPicker';picker.className='training-picker';
 picker.innerHTML='<section class="training-picker-dialog" role="dialog" aria-modal="true" aria-labelledby="pickerTitle"><header class="training-picker-head"><div><small>SELECCIONA TU SIGUIENTE RETO</small><h2 id="pickerTitle">Cambiar entrenamiento</h2></div><button class="picker-close" type="button" aria-label="Cerrar">×</button></header><div class="training-picker-grid"></div><footer><button type="button" class="picker-cancel">Volver a la partida</button></footer></section>';
 document.body.append(picker);
 const pickerGrid=picker.querySelector('.training-picker-grid');let pickerWasActive=false,pickerWasPaused=false,pickerHadPointerLock=false;
 function renderTrainingPicker(){
  if(!pickerGrid)return;pickerGrid.replaceChildren();
  const list=typeof modes!=='undefined'?modes:[];
  const groups=[{name:'FLICK',match:key=>key.startsWith('flick-')},{name:'TRACKING',match:key=>!key.startsWith('flick-')&&!key.startsWith('combo-')&&!key.startsWith('life-track')},{name:'RETOS Y COMBINADOS',match:key=>key.startsWith('combo-')||key.startsWith('life-track')}];
  let order=0;
  for(const group of groups){
   const items=list.filter(mode=>group.match(mode[0]));if(!items.length)continue;
   const section=document.createElement('section');section.className='training-picker-section';
   const heading=document.createElement('h3');heading.textContent=group.name;const grid=document.createElement('div');grid.className='training-picker-section-grid';section.append(heading,grid);
   for(const mode of items){
    const button=document.createElement('button');button.type='button';button.className='training-picker-card';button.dataset.modeKey=mode[0];button.style.setProperty('--tile-order',order++);
    const icon=document.createElement('span');icon.className='picker-glyph';icon.textContent=mode[2]||'◎';
    const copy=document.createElement('span');copy.className='picker-copy';
    const name=document.createElement('b');name.textContent=mode[1];const detail=document.createElement('small');detail.textContent=mode[3]||'Ejercicio de puntería';copy.append(name,detail);button.append(icon,copy);grid.append(button);
   }
   pickerGrid.append(section);
  }
 }
 function openTrainingPicker(){
  if(picker.classList.contains('open'))return;
  pickerWasActive=!!running&&!paused;pickerWasPaused=!!running&&!!paused;pickerHadPointerLock=!!canvas&&document.pointerLockElement===canvas;if(pickerHadPointerLock)document.exitPointerLock?.();
  if(pickerWasActive)pause();renderTrainingPicker();picker.classList.add('open');body.classList.add('training-picker-open');
 }
 function closeTrainingPicker(continueSession=false){
  if(!picker.classList.contains('open'))return;
  picker.classList.remove('open');body.classList.remove('training-picker-open');
  if(continueSession&&pickerWasActive&&running&&paused)pause();
  const restoreCamera=pickerHadPointerLock&&cfg.depth3d;pickerWasActive=pickerWasPaused=pickerHadPointerLock=false;if(continueSession&&restoreCamera)requestCameraLock();
 }
 picker.addEventListener('click',e=>{
  const choice=e.target.closest('[data-mode-key]');
  if(!choice){if(e.target===picker||e.target.closest('.picker-close,.picker-cancel'))closeTrainingPicker(true);return}
  const select=$('#patternSelect'),key=choice.dataset.modeKey,modeInfo=typeof modes!=='undefined'?modes.find(m=>m[0]===key):null;if(!select||!modeInfo)return;
  if(![...select.options].some(option=>option.value===key)){const option=document.createElement('option');option.value=key;option.textContent=modeInfo[1];select.append(option)}
  select.value=key;cfg.pattern=key;if(key==='flick-precision')cfg.size=Math.min(cfg.size,28);if(typeof sync==='function')sync();if(typeof save==='function')save();
  closeTrainingPicker(false);body.classList.add('classic-playing');if(typeof reset==='function')reset();if(typeof start==='function')start();if(cfg.depth3d)requestCameraLock();
 });
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&picker.classList.contains('open')){e.preventDefault();closeTrainingPicker(true)}});

 // Keyboard shortcuts for navigation. Keep them out of text fields and flick sequences.
 const shortcutModal=document.createElement('div');shortcutModal.id='shortcutHelp';shortcutModal.className='shortcut-modal';
 shortcutModal.innerHTML='<section class="shortcut-dialog" role="dialog" aria-modal="true" aria-labelledby="shortcutTitle"><header class="shortcut-head"><div><small>CONTROLES RÁPIDOS</small><h2 id="shortcutTitle">Atajos de teclado</h2></div><button type="button" class="shortcut-close" aria-label="Cerrar">×</button></header><div class="shortcut-list"><div><kbd>T</kbd><span>Entrenamientos</span></div><div><kbd>C</kbd><span>Ajustes</span></div><div><kbd>H</kbd><span>Volver al inicio</span></div><div><kbd>V</kbd><span>Ver la repetición</span></div><div><kbd>ESPACIO</kbd><span>Pausar / continuar</span></div><div><kbd>R</kbd><span>Reiniciar el ejercicio</span></div><div><kbd>E</kbd><span>Activar checkpoint bajo la mira</span></div><div><kbd>F11</kbd><span>Pantalla completa</span></div><div><kbd>?</kbd><span>Mostrar esta guía</span></div></div><footer>Pulsa ESC para cerrar</footer></section>';
 body.append(shortcutModal);
 const toggleShortcutGuide=(force)=>{const open=typeof force==='boolean'?force:!shortcutModal.classList.contains('open');shortcutModal.classList.toggle('open',open);body.classList.toggle('shortcut-guide-open',open)};
 shortcutModal.querySelector('.shortcut-close').addEventListener('click',()=>toggleShortcutGuide(false));
 shortcutModal.addEventListener('mousedown',event=>{if(event.target===shortcutModal)toggleShortcutGuide(false)});
 document.addEventListener('keydown',event=>{
  const target=event.target,tag=target?.tagName?.toLowerCase();
  if(['input','textarea','select'].includes(tag)||target?.isContentEditable)return;
  if(event.key==='Escape'&&shortcutModal.classList.contains('open')){event.preventDefault();event.stopImmediatePropagation();toggleShortcutGuide(false);return}
  if(event.repeat||event.ctrlKey||event.altKey||event.metaKey)return;
  if(event.key==='?'){event.preventDefault();event.stopImmediatePropagation();toggleShortcutGuide();return}
  if(settingsModal.classList.contains('open')||picker.classList.contains('open')||shortcutModal.classList.contains('open'))return;
  const key=event.key.toLowerCase();let handled=true;
  if(key==='t'){if(body.classList.contains('classic-playing'))openTrainingPicker();else $('.welcome-exercises')?.scrollIntoView({behavior:'smooth',block:'start'})}
  else if(key==='c')openSettings();
  else if(key==='h'){if(body.classList.contains('classic-playing'))$('#classicHomeBtn')?.click();else $('#welcome')?.scrollTo({top:0,behavior:'smooth'})}
  else if(key==='v'){const panel=$('#replayPanel');panel?.scrollIntoView({behavior:'smooth',block:'center'});if(!$('#replayPreview')||$('#replayPreview').hidden){const status=$('#replayStatus');if(status)status.textContent='Termina un entrenamiento para preparar su repetición.'}}
  else handled=false;
  if(handled){event.preventDefault();event.stopImmediatePropagation()}
 },true);

 // Add minimal in-game navigation; settings always open as a separate dialog.
 const header=$('header');
 if(header){
  const homeButton=document.createElement('button');homeButton.type='button';homeButton.id='classicHomeBtn';homeButton.className='classic-home-button';homeButton.textContent='← INICIO';
  const drillsButton=document.createElement('button');drillsButton.type='button';drillsButton.id='classicDrillsBtn';drillsButton.className='classic-settings-button';drillsButton.textContent='▤ ENTRENAMIENTOS';
  const settingsButton=document.createElement('button');settingsButton.type='button';settingsButton.id='classicSettingsBtn';settingsButton.className='classic-settings-button';settingsButton.textContent='⚙ VISUALIZACIÓN';
  const helpButton=document.createElement('button');helpButton.type='button';helpButton.id='classicShortcutHelpBtn';helpButton.className='classic-keyboard-button';helpButton.textContent='⌨';helpButton.title='Atajos de teclado · ?';helpButton.setAttribute('aria-label','Ver atajos de teclado');
  header.append(homeButton,drillsButton,settingsButton,helpButton);
  homeButton.addEventListener('click',()=>$('#homeBtn')?.click());
  drillsButton.addEventListener('click',openTrainingPicker);
  settingsButton.addEventListener('click',openSettings);
  helpButton.addEventListener('click',()=>toggleShortcutGuide());
 }
 if($('#enterBtn'))$('#enterBtn').onclick=e=>{e.preventDefault();$('.welcome-exercises')?.scrollIntoView({behavior:'smooth',block:'start'})};
 // Start the selected drill view directly from its card.
 cards?.addEventListener('click',e=>{if(!e.target.closest('.exercise-card'))return;body.classList.add('classic-playing');body.classList.remove('classic-settings-open');const b=$('#classicSettingsBtn');if(b)b.textContent='⚙ VISUALIZACIÓN'},true);
 const homeControl=$('#homeBtn');
 if(homeControl){const old=homeControl.onclick;homeControl.onclick=function(){body.classList.remove('classic-playing','classic-settings-open');const b=$('#classicSettingsBtn');if(b)b.textContent='⚙ VISUALIZACIÓN';return old?.apply(this,arguments)}}

 // Lock the pointer at the view center for direct mouse-look in 3D.
 const canvas=$('#arena');
 const freeAim3DModes=new Set(['tracking-3d-pill']);
 function requestCameraLock(){if(!canvas||!cfg.depth3d||freeAim3DModes.has(cfg.pattern)||document.pointerLockElement===canvas)return;try{const request=canvas.requestPointerLock?.();request?.catch?.(()=>{})}catch{}}
 if(canvas){
  canvas.onclick=null;
  canvas.style.touchAction='none';
  canvas.addEventListener('contextmenu',e=>e.preventDefault());
  canvas.addEventListener('pointerdown',e=>{if(!cfg.depth3d||freeAim3DModes.has(cfg.pattern)||document.pointerLockElement===canvas||e.button!==0)return;requestCameraLock();e.preventDefault();e.stopImmediatePropagation()},true);
  let cameraDrag=null;
  canvas.addEventListener('pointerdown',e=>{
   if(!cfg.depth3d)return;
   const leftOrbit=e.button===0&&!freeAim3DModes.has(cfg.pattern)&&typeof isFlickMode==='function'&&!isFlickMode();
   if(e.button!==2&&!leftOrbit)return;
   cameraDrag={id:e.pointerId,x:e.clientX,y:e.clientY};
   try{canvas.setPointerCapture(e.pointerId)}catch{}
   canvas.classList.add('camera-grabbing');e.preventDefault();
  });
  canvas.addEventListener('pointermove',e=>{
   if(!cameraDrag||cameraDrag.id!==e.pointerId||!cfg.depth3d)return;
   const dx=e.clientX-cameraDrag.x,dy=e.clientY-cameraDrag.y;cameraDrag.x=e.clientX;cameraDrag.y=e.clientY;
   const sens=(cfg.cameraSensitivity||100)/100;
   cameraYaw+=dx*.006*sens;
   cameraPitch=Math.max(-1.52,Math.min(1.52,cameraPitch-dy*.006*sens));e.preventDefault();
  });
  const stopCameraDrag=e=>{if(cameraDrag&&(!e||cameraDrag.id===e.pointerId)){cameraDrag=null;canvas.classList.remove('camera-grabbing')}};
  canvas.addEventListener('pointerup',stopCameraDrag);canvas.addEventListener('pointercancel',stopCameraDrag);canvas.addEventListener('lostpointercapture',stopCameraDrag);
 }
 document.addEventListener('pointerlockchange',()=>{const locked=!!canvas&&document.pointerLockElement===canvas;body.classList.toggle('pointer-locked',locked);if(locked){centerDot.classList.remove('free-aim-reticle');centerDot.style.removeProperty('left');centerDot.style.removeProperty('top')}if(cfg.depth3d){const hint=$('#viewHint');if(hint)hint.textContent=freeAim3DModes.has(cfg.pattern)?'3D · CLIC DERECHO PARA GIRAR · CURSOR LIBRE':locked?'3D · RATÓN GIRA · CLIC DISPARA':'3D · CLIC EN EL CAMPO PARA CENTRAR LA CÁMARA'}});
 /* Wheel scrolling stays native so the page can reach the replay panel. */
 const arenaToolbar=document.createElement('div');arenaToolbar.className='arena-tools';arenaToolbar.innerHTML='<button type="button" data-arena-view="2d">2D</button><button type="button" data-arena-view="3d">3D</button><button type="button" data-arena-action="settings">⚙ AJUSTES</button><button type="button" data-arena-action="trainings">↻ ENTRENAMIENTOS</button>';
 const centerDot=document.createElement('span');centerDot.className='camera-center-dot';centerDot.innerHTML='';centerDot.setAttribute('aria-hidden','true');$('.arena')?.append(arenaToolbar,centerDot);
 const renderReticleSvg=(style,color,length,thickness,gap,size)=>{const k=size/36,L=Math.min(40,length)*k,T=Math.max(1,thickness)*k,G=Math.max(0,gap)*k,extent=Math.max(size*.5,L+G+T+2,12),cx=extent,cy=extent,out=Math.min(extent-2,L+G),inside=Math.min(out-T,G),sw=Math.max(.8,T),line=(x1,y1,x2,y2)=>'<path d="M '+x1.toFixed(2)+' '+y1.toFixed(2)+' L '+x2.toFixed(2)+' '+y2.toFixed(2)+'"/>',circle=(r,fill='none')=>'<circle cx="'+cx+'" cy="'+cy+'" r="'+Math.max(1,r).toFixed(2)+'" fill="'+fill+'"/>',path=(d)=>'<path d="'+d+'"/>',stroke='fill="none" stroke="'+color+'" stroke-width="'+sw.toFixed(2)+'" stroke-linecap="round" stroke-linejoin="round"';let parts=[];const dot=()=>parts.push(circle(Math.max(T*1.6,1),color));const cross=(separated=true)=>{const g0=separated?inside:0;for(const [dx,dy] of [[0,-1],[1,0],[0,1],[-1,0]])parts.push(line(cx+dx*g0,cy+dy*g0,cx+dx*out,cy+dy*out))};if(style==='cross')cross(true);else if(style==='dot')dot();else if(style==='ring')parts.push(circle(Math.max(T*2,G+L*.55)));else if(style==='cross-dot'){cross(true);dot()}else if(style==='circle'){parts.push(circle(Math.max(T*2,G+L*.56)));dot()}else if(style==='square'||style==='hollow-square'){const r=out*.72;parts.push('<rect x="'+(cx-r)+'" y="'+(cy-r)+'" width="'+(2*r)+'" height="'+(2*r)+'" rx="'+(style==='square'?sw*1.4:0)+'"/>')}else if(style==='diamond'){parts.push(path('M '+cx+' '+(cy-out)+' L '+(cx+out)+' '+cy+' L '+cx+' '+(cy+out)+' L '+(cx-out)+' '+cy+' Z'))}else if(style==='x'){for(const [dx,dy] of [[-1,-1],[1,-1],[1,1],[-1,1]])parts.push(line(cx+dx*inside,cy+dy*inside,cx+dx*out,cy+dy*out))}else if(style==='triangle'){parts.push(path('M '+cx+' '+(cy-out)+' L '+(cx+out*.87)+' '+(cy+out*.62)+' L '+(cx-out*.87)+' '+(cy+out*.62)+' Z'))}else if(style==='bracket'){const r=out,short=Math.max(3,L*.45),g0=Math.max(2,G*.5);for(const [dx,dy] of [[-1,-1],[1,-1],[1,1],[-1,1]]){parts.push(line(cx+dx*g0,cy+dy*r,cx+dx*(g0+short),cy+dy*r));parts.push(line(cx+dx*r,cy+dy*g0,cx+dx*r,cy+dy*(g0+short)))}}else if(style==='burst'){for(let i=0;i<8;i++){const a=i*Math.PI/4;parts.push(line(cx+Math.cos(a)*inside,cy+Math.sin(a)*inside,cx+Math.cos(a)*out,cy+Math.sin(a)*out))}}else if(style==='chevron'){for(const [dx,dy] of [[-1,-1],[1,-1],[1,1],[-1,1]]){parts.push(line(cx+dx*out,cy+dy*inside,cx+dx*inside,cy+dy*inside));parts.push(line(cx+dx*inside,cy+dy*inside,cx+dx*inside,cy+dy*out))}}else if(style==='plus')cross(false);else if(style==='circle-cross'){parts.push(circle(Math.max(T*2,G+L*.55)));cross(false)}else if(style==='t'){parts.push(line(cx-out,cy-inside,cx+out,cy-inside));parts.push(line(cx,cy-inside,cx,cy+out))}else if(style==='four-dots'){for(const [dx,dy] of [[0,-1],[1,0],[0,1],[-1,0]])parts.push(circle(Math.max(T*1.2,1),color).replace('cx="'+cx+'" cy="'+cy+'"','cx="'+(cx+dx*(inside+out)/2)+'" cy="'+(cy+dy*(inside+out)/2)+'"'))}else if(style==='hexagon'){const pts=[];for(let i=0;i<6;i++){const a=-Math.PI/2+i*Math.PI/3;pts.push((cx+Math.cos(a)*out).toFixed(2)+' '+(cy+Math.sin(a)*out).toFixed(2))}parts.push(path('M '+pts.join(' L ')+' Z'))}else if(style==='slash'){parts.push(line(cx-out,cy+out,cx+out,cy-out))}else if(style==='star'){const pts=[];for(let i=0;i<10;i++){const a=-Math.PI/2+i*Math.PI/5,r=i%2?out*.43:out;pts.push((cx+Math.cos(a)*r).toFixed(2)+' '+(cy+Math.sin(a)*r).toFixed(2))}parts.push(path('M '+pts.join(' L ')+' Z'))}else if(style==='ring-ticks'){parts.push(circle(Math.max(T*2,G+L*.55)));for(let i=0;i<8;i++){const a=i*Math.PI/4;parts.push(line(cx+Math.cos(a)*(out-sw*1.6),cy+Math.sin(a)*(out-sw*1.6),cx+Math.cos(a)*out,cy+Math.sin(a)*out))}}else if(style==='double-ring'){parts.push(circle(out*.8));parts.push(circle(Math.max(T*2,out*.48)))}return '<svg class="reticle-svg" width="'+size+'" height="'+size+'" viewBox="0 0 '+(extent*2)+' '+(extent*2)+'" xmlns="http://www.w3.org/2000/svg"><g '+stroke+'>'+parts.join('')+'</g></svg>'};
 function syncReticle(){cfg.reticleStyle=cfg.reticleStyle||'cross';cfg.reticleLength=Math.max(4,Math.min(40,Number(cfg.reticleLength)||14));cfg.reticleThickness=Math.max(1,Math.min(8,Number(cfg.reticleThickness)||2));cfg.reticleGap=Math.max(0,Math.min(20,Number.isFinite(Number(cfg.reticleGap))?Number(cfg.reticleGap):4));cfg.reticleRotation=Math.max(0,Math.min(360,Number(cfg.reticleRotation)||0));cfg.reticleColor=/^#[0-9a-f]{6}$/i.test(cfg.reticleColor||'')?cfg.reticleColor:'#ffffff';cfg.reticleSize=Math.max(12,Math.min(120,Number(cfg.reticleSize)||36));cfg.reticleImage=typeof cfg.reticleImage==='string'?cfg.reticleImage:'';for(const node of [centerDot,$('#reticlePreview')])if(node){node.dataset.style=cfg.reticleImage?'image':cfg.reticleStyle;node.style.setProperty('--reticle-rotation',cfg.reticleRotation+'deg');node.style.setProperty('--reticle-size',cfg.reticleSize+'px');node.style.width=cfg.reticleSize+'px';node.style.height=cfg.reticleSize+'px';node.innerHTML=cfg.reticleImage?'<img class="reticle-custom-image" src="'+cfg.reticleImage+'" alt="">':renderReticleSvg(cfg.reticleStyle,cfg.reticleColor,cfg.reticleLength,cfg.reticleThickness,cfg.reticleGap,cfg.reticleSize)}const color=$('#reticleColor'),size=$('#reticleSize'),colorValue=$('#reticleColorValue'),sizeValue=$('#reticleSizeValue');if(color)color.value=cfg.reticleColor;if(size)size.value=cfg.reticleSize;if(colorValue)colorValue.textContent=cfg.reticleColor.toUpperCase();if(sizeValue)sizeValue.textContent=cfg.reticleSize;for(const key of ['Style','Length','Thickness','Gap','Rotation']){const id='reticle'+key,el=$('#'+id),value=cfg[id[0].toLowerCase()+id.slice(1)];if(el)el.value=value;const out=$('#'+id+'Value');if(out)out.textContent=value}const thick=$('#reticleThicknessValue');if(thick)thick.textContent=cfg.reticleThickness;const gap=$('#reticleGapValue');if(gap)gap.textContent=cfg.reticleGap;const rot=$('#reticleRotationValue');if(rot)rot.textContent=cfg.reticleRotation;const len=$('#reticleLengthValue');if(len)len.textContent=cfg.reticleLength}

 for(const id of ['reticleStyle','reticleLength','reticleThickness','reticleGap','reticleRotation','reticleColor','reticleSize'])$('#'+id)?.addEventListener(id==='reticleStyle'?'change':'input',()=>{const key=id[0].toLowerCase()+id.slice(1),el=$('#'+id);cfg[key]=el.type==='range'?Number(el.value):el.value;syncReticle();if(typeof save==='function')save()});
 $('#reticleImageFile')?.addEventListener('change',event=>{const file=event.target.files?.[0];if(!file)return;if(file.size>1024*1024){event.target.value='';return}const reader=new FileReader();reader.onload=()=>{cfg.reticleImage=String(reader.result||'');syncReticle();if(typeof save==='function')save()};reader.readAsDataURL(file)});$('#reticleImageClear')?.addEventListener('click',()=>{cfg.reticleImage='';const input=$('#reticleImageFile');if(input)input.value='';syncReticle();if(typeof save==='function')save()});
 const syncBeforeReticle=window.sync;if(syncBeforeReticle)window.sync=function(){const result=syncBeforeReticle.apply(this,arguments);syncReticle();const label=$('.lower section:first-child>b');if(label)label.textContent=isFlickMode()?'CRONOLOGÍA FLICK':'CRONOLOGÍA TRACKING';return result};syncReticle();const initialTimelineLabel=$('.lower section:first-child>b');if(initialTimelineLabel)initialTimelineLabel.textContent=isFlickMode()?'CRONOLOGÍA FLICK':'CRONOLOGÍA TRACKING';
 const syncArenaView=()=>{arenaToolbar.querySelectorAll('[data-arena-view]').forEach(button=>button.classList.toggle('active',button.dataset.arenaView===(cfg.depth3d?'3d':'2d')));body.classList.toggle('classic-depth-3d',!!cfg.depth3d);if(!cfg.depth3d){centerDot.classList.remove('free-aim-reticle');centerDot.style.removeProperty('left');centerDot.style.removeProperty('top')}};syncArenaView();
 const placeFreeAimReticle=event=>{if(!cfg.depth3d||document.pointerLockElement===canvas)return;const rect=canvas.getBoundingClientRect();centerDot.style.setProperty('left',`${event.clientX-rect.left}px`,'important');centerDot.style.setProperty('top',`${event.clientY-rect.top}px`,'important');centerDot.classList.add('free-aim-reticle')};
 canvas?.addEventListener('mousemove',placeFreeAimReticle);
 canvas?.addEventListener('mouseleave',()=>centerDot.classList.remove('free-aim-reticle'));
 arenaToolbar.addEventListener('click',e=>{const button=e.target.closest('button');if(!button)return;if(button.dataset.arenaAction==='settings'){openSettings();return}if(button.dataset.arenaAction==='trainings'){openTrainingPicker();return}if(button.dataset.arenaView==='2d'){setView3D(false);document.exitPointerLock?.();syncArenaView();return}if(button.dataset.arenaView==='3d'){setView3D(true);requestCameraLock();syncArenaView()}});
 $('#view3d')?.addEventListener('click',requestCameraLock);$('#view2d')?.addEventListener('click',()=>document.exitPointerLock?.());

 // Flick sessions use the same timeline panel to map hits and misses across the run.
 const flickTimelineEvents=[],timelineCanvas=$('#timeline'),timelineCtx=timelineCanvas?.getContext('2d'),baseTimelineDraw=window.timelineDraw;let observedFlickHits=0,observedFlickMisses=0;
 function collectFlickEvents(){if(!isFlickMode())return;while(observedFlickHits<flickHits){flickTimelineEvents.push({t:Math.max(0,elapsed),hit:true});observedFlickHits++}while(observedFlickMisses<flickMisses){flickTimelineEvents.push({t:Math.max(0,elapsed),hit:false});observedFlickMisses++}if(flickTimelineEvents.length>1200)flickTimelineEvents.splice(0,flickTimelineEvents.length-1200)}
 if(window.start){const baseStart=window.start;window.start=function(){flickTimelineEvents.length=0;observedFlickHits=observedFlickMisses=0;return baseStart.apply(this,arguments)}}
 if(window.reset){const baseReset=window.reset;window.reset=function(){flickTimelineEvents.length=0;observedFlickHits=observedFlickMisses=0;return baseReset.apply(this,arguments)}}
 if(window.finish){const baseFinish=window.finish;window.finish=function(){collectFlickEvents();const result=baseFinish.apply(this,arguments);window.timelineDraw?.();return result}}
 if(baseTimelineDraw)window.timelineDraw=function(){
  if(!isFlickMode()||!timelineCtx)return baseTimelineDraw.apply(this,arguments);
  collectFlickEvents();
  const r=timelineCanvas.getBoundingClientRect(),w=r.width,h=r.height;if(!w||!h)return;
  timelineCtx.clearRect(0,0,w,h);timelineCtx.fillStyle='#f7f7f7';timelineCtx.fillRect(0,0,w,h);timelineCtx.strokeStyle='#d0d0d0';timelineCtx.lineWidth=1;
  for(let i=0;i<=4;i++){const y=h*i/4;timelineCtx.beginPath();timelineCtx.moveTo(0,y);timelineCtx.lineTo(w,y);timelineCtx.stroke()}
  timelineCtx.strokeStyle='#555';timelineCtx.beginPath();timelineCtx.moveTo(0,h*.55);timelineCtx.lineTo(w,h*.55);timelineCtx.stroke();
  const total=Math.max(1,Number(cfg.duration)||100);let hits=0,misses=0;
  for(const ev of flickTimelineEvents){const px=Math.max(0,Math.min(w,ev.t/total*w));if(ev.hit){hits++;timelineCtx.strokeStyle='#555';timelineCtx.lineWidth=2;timelineCtx.beginPath();timelineCtx.moveTo(px,h*.55);timelineCtx.lineTo(px,h*.18);timelineCtx.stroke();timelineCtx.fillStyle='#333';timelineCtx.fillRect(px-1,h*.15,3,3)}else{misses++;timelineCtx.strokeStyle='#999';timelineCtx.lineWidth=2;timelineCtx.beginPath();timelineCtx.moveTo(px,h*.55);timelineCtx.lineTo(px,h*.9);timelineCtx.stroke()}}
  timelineCtx.fillStyle='#333';timelineCtx.font='700 9px Arial,sans-serif';timelineCtx.fillText('HITS '+hits+'  /  MISSES '+misses,7,11);
 };

 // Trace flick misses and the longest continuous tracking path for the end-of-run overlay.
 const arenaNode=$('.arena'),reviewCanvas=document.createElement('canvas');reviewCanvas.id='sessionAnalysisCanvas';reviewCanvas.className='session-analysis-canvas';reviewCanvas.setAttribute('aria-hidden','true');arenaNode?.append(reviewCanvas);
 const reviewCtx=reviewCanvas.getContext('2d');let missPoints=[],hitPoints=[],trackingPath=[],bestTrackingPath=[],bestTrackingSeconds=0,lastTraceSample=0,reviewDpr=1;
 function clearReview(){missPoints=[];hitPoints=[];trackingPath=[];bestTrackingPath=[];bestTrackingSeconds=0;lastTraceSample=0;if(reviewCtx)reviewCtx.clearRect(0,0,reviewCanvas.width,reviewCanvas.height);reviewCanvas.classList.remove('visible')}
 function resizeReview(){if(!arenaNode||!reviewCtx)return;const r=arenaNode.getBoundingClientRect();reviewDpr=Math.min(window.devicePixelRatio||1,1.25);reviewCanvas.width=Math.max(1,Math.round(r.width*reviewDpr));reviewCanvas.height=Math.max(1,Math.round(r.height*reviewDpr));reviewCanvas.style.width=r.width+'px';reviewCanvas.style.height=r.height+'px';reviewCtx.setTransform(reviewDpr,0,0,reviewDpr,0,0)}
 function finishTrackingTrace(){
  if(trackingPath.length){const seconds=Math.max(0,(trackingPath[trackingPath.length-1].t-trackingPath[0].t)/1000);if(seconds>bestTrackingSeconds){bestTrackingSeconds=seconds;bestTrackingPath=trackingPath.slice()}}
  trackingPath=[];lastTraceSample=0;
 }
 function sampleTrainingTrace(ts){
  if(running&&paused){requestAnimationFrame(sampleTrainingTrace);return}
  const trackingPhase=typeof isFlickMode==='function'&&(!isFlickMode()||(typeof isComboMode==='function'&&isComboMode()&&comboPhase==='track'));
  if(running&&!paused&&trackingPhase){
   if(inside&&mouse.x>=0&&mouse.y>=0){
    if(lastTraceSample&&ts-lastTraceSample>260)finishTrackingTrace();
    if(!lastTraceSample||ts-lastTraceSample>=55){const w=Math.max(1,canvas.clientWidth),h=Math.max(1,canvas.clientHeight);trackingPath.push({x:mouse.x/w,y:mouse.y/h,t:ts});if(trackingPath.length>1800)trackingPath.shift();lastTraceSample=ts}
   }else finishTrackingTrace();
  }else if(!running)finishTrackingTrace();
  requestAnimationFrame(sampleTrainingTrace);
 }
 requestAnimationFrame(sampleTrainingTrace);
 let flickKeyProgress=0,flickKeyTimer=0;
 const resetFlickKeyProgress=()=>{flickKeyProgress=0;clearTimeout(flickKeyTimer)};
 const flickChordMode=()=>{if(!cfg.flickKeys||typeof isFlickMode!=='function'||!isFlickMode())return false;if(cfg.pattern==='flick-checkpoint'||cfg.pattern==='flick-life')return false;return !isComboMode()||comboPhase==='flick'};
 document.addEventListener('mousedown',event=>{if(!running||paused||event.button!==0||event.target!==canvas||!flickChordMode())return;event.preventDefault();event.stopPropagation();event.stopImmediatePropagation()},true);
 document.addEventListener('keydown',event=>{
  if(!running||paused||!flickChordMode()||event.repeat||event.ctrlKey||event.altKey||event.metaKey)return;
  const tag=event.target?.tagName?.toLowerCase();if(['input','textarea','select'].includes(tag)||event.target?.isContentEditable)return;
  const key=event.key.toUpperCase();if(!/^[A-Z0-9]$/.test(key))return;
  const r=canvas.getBoundingClientRect(),locked=document.pointerLockElement===canvas,mx=locked?r.width/2:mouse.x,my=locked?r.height/2:mouse.y,target=targets.find(item=>!item.dead&&isTargetAt(item,mx,my));
  if(!target){resetFlickKeyProgress();return}
  const sequence=String(cfg.flickKeys||'').toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,4);if(!sequence)return;
  event.preventDefault();event.stopPropagation();event.stopImmediatePropagation();
  if(key===sequence[flickKeyProgress])flickKeyProgress++;else flickKeyProgress=key===sequence[0]?1:0;
  clearTimeout(flickKeyTimer);flickKeyTimer=setTimeout(resetFlickKeyProgress,1200);
  if(flickKeyProgress>=sequence.length){resetFlickKeyProgress();killTarget(target,'flick',{x:mx,y:my});return}
  const note=$('#sessionNote');if(note)note.textContent='FLICK · '+flickKeyProgress+' / '+sequence.length+' TECLAS';
 },true);
 canvas?.addEventListener('mousedown',e=>{
  if(!running||paused||e.button!==0||typeof isFlickMode!=='function'||!isFlickMode()||(typeof isComboMode==='function'&&isComboMode()&&comboPhase!=='flick'))return;
  const r=canvas.getBoundingClientRect(),locked=document.pointerLockElement===canvas,mx=locked?r.width/2:e.clientX-r.left,my=locked?r.height/2:e.clientY-r.top;
  if(targets.some(target=>isTargetAt(target,mx,my)))return;
   missPoints.push({x:mx/Math.max(1,r.width),y:my/Math.max(1,r.height)});if(missPoints.length>400)missPoints.shift();
 },true);
 function drawSessionReview(){
  if(!arenaNode||!reviewCtx)return;if(cfg.depth3d){clearReview();return}$('#rangeOverlay')?.classList.add('hidden');resizeReview();const w=arenaNode.clientWidth,h=arenaNode.clientHeight,q=reviewCtx;
  q.clearRect(0,0,w,h);q.save();
  const flickAnalysis=typeof isFlickMode==='function'&&isFlickMode(),trackingAnalysis=!flickAnalysis||(typeof isComboMode==='function'&&isComboMode());
  if(flickAnalysis){
   for(const p of hitPoints){const px=p.x*w,py=p.y*h;q.beginPath();q.arc(px,py,5,0,Math.PI*2);q.fillStyle='rgba(150,150,150,.82)';q.fill();q.lineWidth=1;q.strokeStyle='rgba(40,40,40,.65)';q.stroke()}
   for(const p of missPoints){const px=p.x*w,py=p.y*h;q.beginPath();q.arc(px,py,3,0,Math.PI*2);q.fillStyle='#111';q.fill();q.lineWidth=1;q.strokeStyle='rgba(255,255,255,.86)';q.stroke()}
  }
  if(trackingAnalysis&&bestTrackingPath.length){
   q.lineCap='round';q.lineJoin='round';q.beginPath();bestTrackingPath.forEach((p,i)=>i?q.lineTo(p.x*w,p.y*h):q.moveTo(p.x*w,p.y*h));
   q.strokeStyle='rgba(255,255,255,.96)';q.lineWidth=8;q.stroke();
   q.strokeStyle='#111111';q.lineWidth=4;q.stroke();
   q.strokeStyle='rgba(255,255,255,.28)';q.lineWidth=1;q.stroke();
   const first=bestTrackingPath[0],last=bestTrackingPath[bestTrackingPath.length-1];
   q.beginPath();q.arc(first.x*w,first.y*h,6,0,Math.PI*2);q.fillStyle='#fff';q.fill();q.lineWidth=2;q.strokeStyle='#111';q.stroke();
   q.beginPath();q.arc(last.x*w,last.y*h,6,0,Math.PI*2);q.fillStyle='#111';q.fill();q.lineWidth=2.5;q.strokeStyle='#fff';q.stroke();
  }
  q.restore();reviewCanvas.classList.add('visible');
 }
 const baseFinish=window.finish,baseStart=window.start,baseReset=window.reset;
 const baseKillTarget=window.killTarget;
 if(baseKillTarget)window.killTarget=function(target,kind,point){if(!cfg.depth3d&&['flick','flick-life','checkpoint'].includes(kind)&&target){const w=Math.max(1,canvas.clientWidth),h=Math.max(1,canvas.clientHeight);hitPoints.push({x:(Number.isFinite(point?.x)?point.x:target.x)/w,y:(Number.isFinite(point?.y)?point.y:target.y)/h});if(hitPoints.length>400)hitPoints.shift()}return baseKillTarget.apply(this,arguments)};
 if(baseFinish)window.finish=function(){finishTrackingTrace();const result=baseFinish.apply(this,arguments);drawSessionReview();return result};
 if(baseReset)window.reset=function(){resetFlickKeyProgress();clearReview();return baseReset.apply(this,arguments)};
 if(baseStart)window.start=function(){resetFlickKeyProgress();if(!running)clearReview();return baseStart.apply(this,arguments)};
 window.addEventListener('resize',()=>{if(reviewCanvas.classList.contains('visible'))drawSessionReview()});

 const originalSync=window.sync;
 if(originalSync){window.sync=function(){const out=originalSync.apply(this,arguments);const hint=$('#viewHint');if(hint)hint.textContent=cfg.depth3d?(document.pointerLockElement===canvas?'3D · RATÓN GIRA · CLIC DISPARA':'3D · CLIC EN EL CAMPO PARA CENTRAR LA CÁMARA'):'PUNTERO DEL SISTEMA';syncArenaView();return out}}

 // Remove remaining visible legacy labels and expose only one interface.
 // Remove only the legacy page footer. Settings and training dialogs use their own footers.
 document.querySelectorAll('#interfaceSelect,#interfaceSelectWelcome,.interface-select,#consoleNav,#dsyIntro,body>footer').forEach(n=>n.remove());
 const targetStyle=$('#targetType');if(targetStyle){const label=targetStyle.closest('label');if(label)label.querySelector('span')?.remove()}
 const environmentInput=$('#sceneColor');if(environmentInput){const label=environmentInput.closest('label');if(label){label.classList.remove('legacy-control');label.childNodes[0].textContent='COLOR DEL ESCENARIO';label.style.removeProperty('display')}}
 const baseColorInput=$('#backgroundColor');baseColorInput?.closest('label')?.style.setProperty('display','none','important');
 ['hudAccent','hudPanel'].forEach(id=>$('#'+id)?.closest('label')?.style.setProperty('display','none','important'));
 const targetColorInput=$('#targetColor');if(targetColorInput?.parentElement?.previousElementSibling)targetColorInput.parentElement.previousElementSibling.textContent='COLOR DEL OBJETIVO';
 const playerColor=$('#cursorColor');if(playerColor){const label=playerColor.closest('label');if(label)label.remove()}
 const ambient=$('#ambientScene');if(ambient){for(const option of ambient.options)if(option.value==='hangar')option.textContent='Hangar silencioso'}
 const scenes3d=$('#arena3d');if(scenes3d){for(const option of scenes3d.options)option.textContent=option.textContent.replace(/DSY\s*/gi,'')}
 const particles=$('#dsyParticleStyle');if(particles){for(const option of particles.options)if(option.value==='sparks')option.textContent='Chispas'}
 const hits=$('#hitSound');if(hits){const names={'dsy-impact':'Impacto fuerte','dsy-spark':'Chispa brillante','dsy-wave':'Onda resonante'};for(const option of hits.options)if(names[option.value])option.textContent=names[option.value]}
 const legacyRank=$('#dsyHomeRank');if(legacyRank){const small=legacyRank.querySelector('small');if(small)small.textContent='AIM OVERDRIVE · CLASIFICACIÓN';}
 document.querySelectorAll('.DSY-mark').forEach(el=>{el.className='classic-mark';el.textContent=mark});
 const cleanLegacyText=root=>{const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);let node;while(node=walker.nextNode())if(/DSY/i.test(node.nodeValue))node.nodeValue=node.nodeValue.replace(/DSY/gi,'').replace(/\s{2,}/g,' ')};
 cleanLegacyText(document.body);
 const brandObserver=new MutationObserver(records=>records.forEach(record=>{if(record.type==='characterData'&&/DSY/i.test(record.target.nodeValue))record.target.nodeValue=record.target.nodeValue.replace(/DSY/gi,'').replace(/\s{2,}/g,' ');record.addedNodes?.forEach(node=>{if(node.nodeType===Node.TEXT_NODE&&/DSY/i.test(node.nodeValue))node.nodeValue=node.nodeValue.replace(/DSY/gi,'');else if(node.nodeType===Node.ELEMENT_NODE)cleanLegacyText(node)})}));
 brandObserver.observe(document.body,{subtree:true,childList:true,characterData:true});
 groupCards();
})();



