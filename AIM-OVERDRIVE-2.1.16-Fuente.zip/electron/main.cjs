const { app, BrowserWindow, shell, dialog, ipcMain } = require('electron');
const fs = require('node:fs');
const path = require('node:path');
const replayStreams = new Map();

ipcMain.handle('window:set-fullscreen', (event, enabled) => {
  const win = BrowserWindow.fromWebContents(event.sender);
  if (!win || win.isDestroyed()) return false;
  win.setFullScreen(!!enabled);
  return win.isFullScreen();
});

ipcMain.handle('window:is-fullscreen', (event) => {
  const win = BrowserWindow.fromWebContents(event.sender);
  return !!win && !win.isDestroyed() && win.isFullScreen();
});

ipcMain.handle('replay:save:begin', async (event, suggestedName) => {
  const safeName = String(suggestedName || 'Aim-Overdrive-Replay.webm')
    .replace(/[<>:"/\\|?*\x00-\x1f]/g, '-')
    .slice(0, 120);
  const options = {
    title: 'Guardar replay de AIM OVERDRIVE',
    defaultPath: path.join(app.getPath('videos'), safeName.endsWith('.webm') ? safeName : `${safeName}.webm`),
    filters: [{ name: 'Video WebM', extensions: ['webm'] }]
  };
  const parent = BrowserWindow.fromWebContents(event.sender);
  const result = parent
    ? await dialog.showSaveDialog(parent, options)
    : await dialog.showSaveDialog(options);
  if (result.canceled || !result.filePath) return { canceled: true };

  const previous = replayStreams.get(event.sender.id);
  previous?.stream.destroy();
  const stream = fs.createWriteStream(result.filePath, { flags: 'w' });
  stream.on('error', () => {});
  await new Promise((resolve, reject) => {
    stream.once('open', resolve);
    stream.once('error', reject);
  });
  replayStreams.set(event.sender.id, { stream, filePath: result.filePath });
  return { canceled: false, filePath: result.filePath };
});

ipcMain.handle('replay:save:chunk', async (event, data) => {
  const entry = replayStreams.get(event.sender.id);
  if (!entry) throw new Error('No hay un archivo replay abierto para escribir.');
  let bytes;
  if (data instanceof ArrayBuffer) bytes = Buffer.from(data);
  else if (ArrayBuffer.isView(data)) bytes = Buffer.from(data.buffer, data.byteOffset, data.byteLength);
  else throw new Error('El fragmento del replay no es válido.');
  if (!bytes.length || bytes.length > 20 * 1024 * 1024) throw new Error('El fragmento del replay excede el límite permitido.');
  await new Promise((resolve, reject) => entry.stream.write(bytes, error => error ? reject(error) : resolve()));
  return true;
});

ipcMain.handle('replay:save:end', async (event) => {
  const entry = replayStreams.get(event.sender.id);
  if (!entry) throw new Error('No hay un replay abierto para finalizar.');
  await new Promise((resolve, reject) => {
    entry.stream.once('error', reject);
    entry.stream.end(resolve);
  });
  replayStreams.delete(event.sender.id);
  return { filePath: entry.filePath };
});

ipcMain.handle('replay:save:abort', async (event) => {
  const entry = replayStreams.get(event.sender.id);
  if (!entry) return true;
  replayStreams.delete(event.sender.id);
  entry.stream.destroy();
  await fs.promises.unlink(entry.filePath).catch(() => {});
  return true;
});

function createWindow() {
  const win = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 920,
    minHeight: 640,
    backgroundColor: '#050607',
    show: false,
    autoHideMenuBar: true,
    icon: path.join(__dirname, '..', 'build', 'aim-overdrive.ico'),
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      preload: path.join(__dirname, 'preload.cjs')
    }
  });
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith('https://www.roblox.com/')) shell.openExternal(url);
    return { action: 'deny' };
  });
  win.once('ready-to-show', () => win.show());
  win.webContents.once('destroyed', () => {
    const entry = replayStreams.get(win.webContents.id);
    if (entry) { entry.stream.destroy(); replayStreams.delete(win.webContents.id); }
  });
  win.loadFile(path.join(__dirname, '..', 'index.html'));
}

app.whenReady().then(() => {
  app.setAppUserModelId('com.aimoverdrive.desktop');
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
