const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('replayNative', Object.freeze({
  beginSave: (filename) => ipcRenderer.invoke('replay:save:begin', filename),
  writeChunk: (data) => ipcRenderer.invoke('replay:save:chunk', data),
  finishSave: () => ipcRenderer.invoke('replay:save:end'),
  abortSave: () => ipcRenderer.invoke('replay:save:abort')
}));

contextBridge.exposeInMainWorld('aimDesktop', Object.freeze({
  setFullscreen: (enabled) => ipcRenderer.invoke('window:set-fullscreen', !!enabled),
  isFullscreen: () => ipcRenderer.invoke('window:is-fullscreen')
}));
