/* AIM OVERDRIVE 2.1.16 — focused gameplay and reliability pass */
(() => {
  'use strict';

  const $ = (selector) => document.querySelector(selector);
  const now = () => performance.now();
  const extraModes = [
    ['tracking-line-x', 'Line Tracking · X', '↔', 'Follow a perfectly straight horizontal route. It reverses only at the edge.'],
    ['tracking-line-y', 'Line Tracking · Y', '↕', 'Follow a perfectly straight vertical route. It reverses only at the edge.'],
    ['tracking-line-diagonal', 'Line Tracking · Diagonal', '↗', 'Follow a clean diagonal route with a straight reversal at each end.'],
    ['tracking-line-offset', 'Line Tracking · Offset', '⤢', 'Follow a straight route at a changing diagonal angle.'],
    ['tracking-3d-pill', 'Pill Track · 3D', '▰', 'Track a pill target across the far end of the room as it makes random jumps.'],
    ['flick-straight', 'Straight Line Flick', '⌁', 'Flick a moving target that follows a straight line and bounces at the field edges.'],
    ['flick-speed-five', 'Five in Five', '5×', 'Clear five targets before each five-second countdown expires.'],
    ['flick-speed-moving', 'Five in Five · Moving', '≫', 'Clear five moving targets in five seconds; a new wave starts when all five are hit.'],
    ['flick-speed-micro', 'Five in Five · Micro', '⁙', 'Clear five small targets in each five-second wave.']
  ];
  function readCustomTrainings() {
    try {
      const list = JSON.parse(localStorage.getItem('aoCustomTrainings') || '[]');
      return Array.isArray(list) ? list.filter((item) => item && /^[a-z0-9]{5,24}$/i.test(item.id) && ['flick', 'tracking'].includes(item.type) && Array.isArray(item.points) && item.points.length >= 2) : [];
    } catch { return []; }
  }
  let customTrainings = readCustomTrainings();
  const customModePrefix = (item) => `${item.type}-custom-${item.id}`;
  const customModeMap = new Map();
  function registerCustomTraining(item) {
    const id = customModePrefix(item), label = String(item.name || 'Mi entrenamiento').slice(0, 28);
    customModeMap.set(id, item);
    if (!modes.some((mode) => mode[0] === id)) modes.push([id, label, item.type === 'flick' ? '✦' : '↗', item.type === 'flick' ? 'Recorrido personalizado de flick.' : 'Recorrido personalizado de tracking.']);
    const select = document.querySelector('#patternSelect');
    if (select && !Array.from(select.options).some((option) => option.value === id)) select.add(new Option(label, id));
  }
  customTrainings.forEach(registerCustomTraining);
  const modeCopy = {
    'tracking-line-x': { es: ['Seguimiento lineal · X', 'Sigue una ruta horizontal perfectamente recta; cambia de dirección solo al tocar el borde.'], en: ['Line Tracking · X', 'Follow a perfectly straight horizontal route. It reverses only at the edge.'] },
    'tracking-line-y': { es: ['Seguimiento lineal · Y', 'Sigue una ruta vertical perfectamente recta; cambia de dirección solo al tocar el borde.'], en: ['Line Tracking · Y', 'Follow a perfectly straight vertical route. It reverses only at the edge.'] },
    'tracking-line-diagonal': { es: ['Seguimiento lineal · diagonal', 'Sigue una diagonal continua; rebota en cada borde y cambia el ángulo al chocar.'], en: ['Line Tracking · Diagonal', 'Follow a continuous diagonal route; each wall bounce changes the angle.'] },
    'tracking-line-offset': { es: ['Seguimiento lineal · ángulo variable', 'Sigue una línea recta con un ángulo diagonal distinto en cada aparición.'], en: ['Line Tracking · Offset', 'Follow a straight route at a changing diagonal angle.'] },
    'tracking-3d-pill': { es: ['Seguimiento de píldora · 3D', 'Sigue una píldora al fondo del cuarto mientras cruza y da saltos aleatorios.'], en: ['Pill Track · 3D', 'Track a pill target across the far end of the room as it makes random jumps.'] },
    'flick-straight': { es: ['Flick lineal', 'Haz flick a un objetivo móvil que rebota en una línea recta al tocar los bordes.'], en: ['Straight Line Flick', 'Flick a moving target that bounces along a straight path at the field edges.'] },
    'flick-speed-five': { es: ['Cinco en cinco', 'Elimina cinco objetivos antes de que termine cada cuenta regresiva de cinco segundos.'], en: ['Five in Five', 'Clear five targets before each five-second countdown expires.'] },
    'flick-speed-moving': { es: ['Cinco en cinco · móvil', 'Cinco objetivos móviles y cinco segundos para despejar cada oleada.'], en: ['Five in Five · Moving', 'Clear five moving targets in five seconds; a new wave starts when all five are hit.'] },
    'flick-speed-micro': { es: ['Cinco en cinco · micro', 'Limpia cinco objetivos pequeños en cada oleada de cinco segundos.'], en: ['Five in Five · Micro', 'Clear five small targets in each five-second wave.'] }
  };
  const patternSelect = $('#patternSelect');
  if (typeof modes !== 'undefined' && Array.isArray(modes)) {
    for (const row of extraModes) {
      if (!modes.some((item) => item[0] === row[0])) modes.push(row);
      if (patternSelect && !Array.from(patternSelect.options).some((option) => option.value === row[0])) {
        patternSelect.add(new Option(row[1], row[0]));
      }
    }
  }

  // Keep a compact set of distinct tracking drills. The four straight-line
  // exercises remain available, alongside the core movement families.
  const retainedTracking = new Set(['horizontal', 'vertical', 'diagonal', 'circular', 'reactive', 'multi', 'switching', 'tracking-line-x', 'tracking-line-y', 'tracking-line-diagonal', 'tracking-line-offset', 'tracking-3d-pill']);
  if (typeof modes !== 'undefined' && Array.isArray(modes)) {
    for (let i = modes.length - 1; i >= 0; i--) {
      const id = modes[i][0];
      const trackingLike = !id.startsWith('flick-') && !id.startsWith('combo-') && !id.startsWith('life-track') && !id.includes('-custom-');
      if (trackingLike && !retainedTracking.has(id)) {
        modes.splice(i, 1);
        patternSelect?.querySelector(`option[value="${id}"]`)?.remove();
      }
    }
    if (!modes.some((item) => item[0] === cfg.pattern)) cfg.pattern = 'horizontal';
    drawModes?.();
  }

  const lineTrackingModes = new Set(['tracking-line-x', 'tracking-line-y', 'tracking-line-diagonal', 'tracking-line-offset']);
  const lineModes = new Set([...lineTrackingModes, 'flick-straight', 'flick-speed-moving']);
  const freeAim3DModes = new Set(['tracking-3d-pill']);
  const waveModes = new Set(['flick-speed-five', 'flick-speed-moving', 'flick-speed-micro']);
  let waveDeadline = 0;
  let waveNumber = 0;
  let waveFailed = false;
  let pauseStartedAt = 0;
  let exactAimNext = 0;
  let checkpointWaveHits = 0;

  function registerModes() {
    if (!patternSelect) return;
    for (const [id, label] of extraModes) {
      if (!Array.from(patternSelect.options).some((option) => option.value === id)) {
        patternSelect.add(new Option(label, id));
      }
    }
  }

  function getCount() {
    if (lineTrackingModes.has(cfg.pattern) || ['flick-straight', 'tracking-3d-pill'].includes(cfg.pattern) || customModeMap.has(cfg.pattern)) return 1;
    if (waveModes.has(cfg.pattern)) return 5;
    if (cfg.pattern === 'flick-40-shrink') return 40;
    return null;
  }

  const previousCount = window.targetCountForMode;
  if (previousCount) {
    window.targetCountForMode = function () {
      const count = getCount();
      return count == null ? previousCount.apply(this, arguments) : count;
    };
  }

  // The room is a real world-space box. Targets stay within its inside faces;
  // their route no longer follows the camera, so it cannot look like a HUD overlay.
  const roomBounds = { x: [-12.4, 12.4], y: [-2.6, 5.5], z: [4.5, 17.2] };
  function randomIn([min, max]) { return min + Math.random() * (max - min); }

  function prepareLineTarget(target) {
    if (!target || !lineModes.has(cfg.pattern)) return target;
    let vx = 1, vy = 0;
    if (cfg.pattern === 'tracking-line-y') { vx = 0; vy = 1; }
    else if (cfg.pattern === 'tracking-line-diagonal') { vx = 1; vy = Math.random() < .5 ? -1 : 1; }
    else if (cfg.pattern === 'tracking-line-offset') { const angle = randomIn([24, 67]) * Math.PI / 180; vx = Math.cos(angle); vy = (Math.random() < .5 ? -1 : 1) * Math.sin(angle); }
    else if (cfg.pattern === 'tracking-straight' || cfg.pattern === 'flick-straight' || cfg.pattern === 'flick-speed-moving') { const angle = randomIn([24, 67]) * Math.PI / 180; vx = Math.cos(angle); vy = (Math.random() < .5 ? -1 : 1) * Math.sin(angle); }
    const magnitude = Math.hypot(vx, vy) || 1;
    target.lineVX = vx / magnitude;
    target.lineVY = vy / magnitude;
    target.lineDir = Math.random() < .5 ? -1 : 1;
    target.lineInitialized = true;
    if (cfg.depth3d) {
      target.lineBaseX = 0;
      target.lineBaseY = 0.5;
      target.lineDepth = target.lineZ = 14.5;
      const halfX = 7.4, halfY = 2.5;
      target.lineExtent = Math.min(target.lineVX ? halfX / Math.abs(target.lineVX) : Infinity, target.lineVY ? halfY / Math.abs(target.lineVY) : Infinity);
      target.lineT = randomIn([-target.lineExtent * .48, target.lineExtent * .48]);
      target.world3D = { x: target.lineBaseX + target.lineVX * target.lineT, y: target.lineBaseY + target.lineVY * target.lineT, z: target.lineZ };
      target.worldHome = { ...target.world3D };
      target.hidden3d = false;
    } else {
      target.lineBaseX = range.x + range.w / 2;
      target.lineBaseY = range.y + range.h / 2;
      const dims = typeof targetDimensions === 'function' ? targetDimensions(target) : { rad: 18 };
      const margin = Math.max(14, dims.rad || 18);
      target.lineExtent = Math.min(target.lineVX ? Math.max(1, range.w / 2 - margin) / Math.abs(target.lineVX) : Infinity, target.lineVY ? Math.max(1, range.h / 2 - margin) / Math.abs(target.lineVY) : Infinity);
      target.lineT = randomIn([-target.lineExtent * .5, target.lineExtent * .5]);
      target.x = target.lineBaseX + target.lineVX * target.lineT;
      target.y = target.lineBaseY + target.lineVY * target.lineT;
    }
    if (cfg.pattern === 'flick-speed-micro') target.specialScale = Math.min(target.specialScale || 1, 0.78);
    if (cfg.pattern === 'flick-speed-five') target.specialScale = Math.min(target.specialScale || 1.18, 1.18);
    return target;
  }

  const previousNewTarget = window.newT;
  if (previousNewTarget) {
    window.newT = function () {
      const target = previousNewTarget.apply(this, arguments);
      const custom = customModeMap.get(cfg.pattern);
      if (custom) {
        target.customRoute = custom.points;
        target.customDuration = Math.max(3, Math.min(60, Number(custom.duration) || 10));
        target.customPhase = Math.random() * target.customDuration;
        target.customRate = .88 + Math.random() * .24;
        target.customFlipX = Math.random() < .5 ? -1 : 1;
        target.customFlipY = Math.random() < .5 ? -1 : 1;
        target.customRouteStart = Number(elapsed) || 0;
      }
      if (cfg.pattern === 'flick-40-shrink') target.specialScale = 1.7;
      if (cfg.depth3d && cfg.pattern === 'tracking-3d-pill') {
        target.pillBaseY = -3.15;
        target.pillHopStart = -1;
        target.pillHopDuration = .55;
        target.pillHopHeight = 0;
        target.pillNextHop = .8 + Math.random() * 1.4;
        target.pillVX = Math.random() < .5 ? -1 : 1;
        target.world3D = { x: randomIn([-8.2, 8.2]), y: target.pillBaseY, z: 17.2 };
        target.worldHome = { ...target.world3D };
        target.hidden3d = false;
      }
      return prepareLineTarget(target);
    };
  }

  const previousTargetDraw = window.drawGameTarget;
  if (previousTargetDraw) {
    window.drawGameTarget = function (target) {
      if (target?.dead || target?.hidden3d) return;
      if (cfg.depth3d && freeAim3DModes.has(cfg.pattern)) {
        const d = targetDimensions(target), width = Math.max(13, d.rad * 2.25), height = Math.max(9, d.rad * .95), radius = height / 2;
        x.save(); x.translate(target.x, target.y); x.rotate((target.pillTilt || 0) + Math.PI / 2);
        x.fillStyle = cfg.targetColor || '#d0d0d0'; x.strokeStyle = '#f4f4f4'; x.lineWidth = Math.max(1.2, height * .09);
        x.shadowColor = '#eeeeee'; x.shadowBlur = 5;
        x.beginPath(); x.moveTo(-width / 2 + radius, -height / 2); x.lineTo(width / 2 - radius, -height / 2); x.arcTo(width / 2, -height / 2, width / 2, 0, radius); x.arcTo(width / 2, height / 2, width / 2 - radius, height / 2, radius); x.lineTo(-width / 2 + radius, height / 2); x.arcTo(-width / 2, height / 2, -width / 2, 0, radius); x.arcTo(-width / 2, -height / 2, -width / 2 + radius, -height / 2, radius); x.closePath(); x.fill(); x.shadowBlur = 0; x.stroke();
        x.globalAlpha = .5; x.fillStyle = '#ffffff'; x.fillRect(-width * .24, -height * .2, width * .46, Math.max(1, height * .12)); x.restore(); return;
      }
      if (cfg.pattern === 'flick-exact-aim' && Number.isFinite(target.dsyBorn)) {
        const progress = Math.max(0, Math.min(1, (now() - target.dsyBorn) / 5200));
        x.save(); x.globalAlpha = progress > .82 ? Math.max(0, 1 - (progress - .82) / .18) : 1; previousTargetDraw.apply(this, arguments); x.restore(); return;
      }
      return previousTargetDraw.apply(this, arguments);
    };
  }

  function bounce(position, velocity, min, max, step) {
    if (max <= min) return { position: (min + max) / 2, velocity };
    let next = position + velocity * step;
    let guard = 0;
    while ((next < min || next > max) && guard++ < 8) {
      if (next < min) { next = min + (min - next); velocity = Math.abs(velocity); }
      if (next > max) { next = max - (next - max); velocity = -Math.abs(velocity); }
    }
    return { position: Math.max(min, Math.min(max, next)), velocity };
  }

  const previousMove = window.move;
  if (previousMove) {
    window.move = function (target, stamp, delta) {
      const custom = customModeMap.get(cfg.pattern);
      if (custom && target?.customRoute?.length) {
        if (paused) return;
        const route = target.customRoute, duration = target.customDuration || 10;
        const time = (((((Number(elapsed) || 0) - (target.customRouteStart || 0)) * (target.customRate || 1) + target.customPhase) % duration) + duration) % duration;
        const t = time / duration * (route.length - 1), index = Math.min(route.length - 2, Math.floor(t)), mix = t - index;
        const a = route[index], b = route[index + 1];
        const px = Math.max(.04, Math.min(.96, (Number(a.x) + (Number(b.x) - Number(a.x)) * mix - .5) * target.customFlipX + .5));
        const py = Math.max(.06, Math.min(.94, (Number(a.y) + (Number(b.y) - Number(a.y)) * mix - .5) * target.customFlipY + .5));
        if (cfg.depth3d) {
          target.world3D = { x: (px - .5) * 15.2, y: (0.5 - py) * 6.6 + .45, z: 14.5 };
          const projected = project3D(target.world3D.x, target.world3D.y, target.world3D.z, c.clientWidth, c.clientHeight);
          target.hidden3d = !projected;
          if (projected) { target.x = projected.x; target.y = projected.y; target.viewScale = Math.max(.55, Math.min(1.2, 13 / projected.depth)); }
        } else {
          target.x = range.x + range.w * px; target.y = range.y + range.h * py;
        }
        return;
      }
      if (cfg.depth3d && cfg.pattern === 'tracking-3d-pill' && target?.world3D) {
        if (paused) return;
        const dt = Math.min(50, Math.max(0, Number(delta) || 16)) / 1000;
        const horizontal = bounce(target.world3D.x, target.pillVX * (Number(cfg.speed) || 220) / 95, -8.2, 8.2, dt);
        target.world3D.x = horizontal.position;
        target.pillVX = horizontal.velocity > 0 ? 1 : -1;
        if ((Number(elapsed) || 0) >= target.pillNextHop) {
          target.pillHopStart = Number(elapsed) || 0;
          target.pillHopDuration = .48 + Math.random() * .34;
          target.pillHopHeight = 1.25 + Math.random() * 1.6;
          target.pillNextHop = target.pillHopStart + 1.1 + Math.random() * 1.5;
        }
        const jumpProgress = target.pillHopStart < 0 ? 1 : Math.max(0, Math.min(1, ((Number(elapsed) || 0) - target.pillHopStart) / target.pillHopDuration));
        const jump = jumpProgress < 1 ? Math.sin(Math.PI * jumpProgress) * target.pillHopHeight : 0;
        target.world3D.y = target.pillBaseY + jump;
        const projected = project3D(target.world3D.x, target.world3D.y, target.world3D.z, c.clientWidth, c.clientHeight);
        target.hidden3d = !projected;
        if (projected) { target.x = projected.x; target.y = projected.y; target.viewScale = Math.max(.5, Math.min(1.2, 12 / projected.depth)); }
        return;
      }
      if (!lineModes.has(cfg.pattern)) return previousMove.apply(this, arguments);
      if (paused) return;
      if (!target.lineInitialized) prepareLineTarget(target);
      const dt = Math.min(50, Math.max(0, Number(delta) || 16)) / 1000;
      const speed = Math.max(35, (Number(target.speed) || Number(cfg.speed) || 220) + (Number(cfg.acceleration) || 0) / 100 * Math.min(elapsed || 0, 60));
      if (cfg.pattern === 'tracking-line-diagonal') {
        const vx = target.lineVX || .707, vy = target.lineVY || .707;
        if (cfg.depth3d && target.world3D) {
          const step = speed / 110 * dt, nextX = target.world3D.x + vx * step, nextY = target.world3D.y + vy * step;
          if (nextX < -7.4 || nextX > 7.4) { target.lineVX *= -1; target.world3D.x = Math.max(-7.4, Math.min(7.4, nextX)); } else target.world3D.x = nextX;
          if (nextY < -2.05 || nextY > 3.15) { target.lineVY *= -1; target.world3D.y = Math.max(-2.05, Math.min(3.15, nextY)); } else target.world3D.y = nextY;
          const projected = project3D(target.world3D.x, target.world3D.y, target.world3D.z, c.clientWidth, c.clientHeight);
          target.hidden3d = !projected;
          if (projected) { target.x = projected.x; target.y = projected.y; target.viewScale = Math.max(.58, Math.min(1.25, 13 / projected.depth)); }
        } else {
          const dims = typeof targetDimensions === 'function' ? targetDimensions(target) : { rad: 18 }, margin = Math.max(14, dims.rad || 18);
          const minX = range.x + margin, maxX = range.x + range.w - margin, minY = range.y + margin, maxY = range.y + range.h - margin;
          const nextX = target.x + vx * speed * dt, nextY = target.y + vy * speed * dt;
          if (nextX < minX || nextX > maxX) { target.lineVX *= -1; target.x = Math.max(minX, Math.min(maxX, nextX)); } else target.x = nextX;
          if (nextY < minY || nextY > maxY) { target.lineVY *= -1; target.y = Math.max(minY, Math.min(maxY, nextY)); } else target.y = nextY;
        }
        return;
      }
      if (cfg.depth3d && target.world3D) {
        const pos = bounce(target.lineT, target.lineDir * speed / 110, -target.lineExtent, target.lineExtent, dt);
        target.lineT = pos.position; target.lineDir = pos.velocity >= 0 ? 1 : -1;
        target.world3D = { x: target.lineBaseX + target.lineVX * target.lineT, y: target.lineBaseY + target.lineVY * target.lineT, z: target.lineZ };
        const projected = project3D(target.world3D.x, target.world3D.y, target.world3D.z, c.clientWidth, c.clientHeight);
        target.hidden3d = !projected;
        if (projected) {
          target.x = projected.x; target.y = projected.y;
          target.viewScale = Math.max(0.58, Math.min(1.25, 13 / projected.depth));
        }
        return;
      }
      const pos = bounce(target.lineT, target.lineDir * speed, -target.lineExtent, target.lineExtent, dt);
      target.lineT = pos.position; target.lineDir = pos.velocity >= 0 ? 1 : -1;
      target.x = target.lineBaseX + target.lineVX * target.lineT;
      target.y = target.lineBaseY + target.lineVY * target.lineT;
    };
  }

  function waveLabel() {
    let label = $('#waveTimer');
    if (!label) {
      label = document.createElement('span');
      label.id = 'waveTimer';
      label.className = 'wave-timer';
      $('.range .meta')?.append(label);
    }
    return label;
  }

  function setWaveTargets() {
    targets = createSessionTargets();
    const shrink = Math.max(0.64, 1 - Math.max(0, waveNumber - 1) * 0.025);
    targets.forEach((target) => {
      target.dead = false;
      target.specialScale = Math.min(target.specialScale || 1, shrink);
      if (cfg.pattern === 'flick-speed-moving') prepareLineTarget(target);
    });
    waveDeadline = now() + 5000;
    const timer = waveLabel();
    if (timer) timer.textContent = `OLEADA ${waveNumber} · 5.0 s`;
  }

  const previousKill = window.killTarget;
  if (previousKill) {
    window.killTarget = function (target, kind, point) {
      const pattern = cfg.pattern;
      if (!target || target.dead) return;
      if (pattern === 'flick-checkpoint') {
        try { pending = false; checkpointPending = false; } catch { }
      }
      const beforeLength = targets.length;
      const beforeExactCount = typeof exactCount === 'number' ? exactCount : 1;
      const priorPattern = cfg.pattern;
      if (pattern === 'flick-40-shrink') cfg.pattern = 'flick-40';
      const result = previousKill.apply(this, arguments);
      cfg.pattern = priorPattern;

      if (pattern === 'flick-checkpoint') {
        checkpointWaveHits++;
        try { pending = false; checkpointPending = false; checkpointHits = 0; } catch { }
        if (typeof targets !== 'undefined') {
          targets.forEach((item) => { delete item.dsyDeadline; });
          if (checkpointWaveHits >= 5) {
            checkpointWaveHits = 0;
            checkpointDeadline = elapsed + 5;
          }
        }
        if (typeof pulses !== 'undefined') pulses.length = 0;
      }

      if (pattern === 'flick-exact-aim') {
        targets.length = Math.min(targets.length, beforeLength);
        if (typeof exactCount === 'number') exactCount = beforeExactCount;
        target.dsyBorn = now(); target.exactStart = target.dsyBorn; target.spawnAt = target.dsyBorn; target.dead = false;
      }

      if (waveModes.has(pattern)) {
        target.dead = true;
        delete target.dsyDeadline;
        if (!targets.some((item) => !item.dead)) {
          waveNumber++;
          setWaveTargets();
          const note = $('#sessionNote');
          if (note) note.textContent = `OLEADA ${waveNumber}: cinco objetivos nuevos · 5 segundos`;
        }
      }

      if (pattern === 'flick-40' || pattern === 'flick-40-shrink') {
        if (!targets.some((item) => !item.dead)) {
          const note = $('#sessionNote');
          if (note) note.textContent = '40/40 · campo despejado';
          window.finish?.();
        }
      }

      if (cfg.depth3d) {
        if (typeof deathMarks !== 'undefined') deathMarks.length = 0;
        if (typeof impactFx !== 'undefined') impactFx.length = 0;
        if (typeof particles !== 'undefined') particles.length = 0;
        if (typeof pulses !== 'undefined') pulses.length = 0;
      }
      return result;
    };
  }

  const previousStart = window.start;
  if (previousStart) {
    window.start = function () {
      const resume = !!running && !!paused;
      if (!resume) {
        waveNumber = 1; waveFailed = false; checkpointWaveHits = 0;
        exactAimNext = 5.2;
      }
      if (freeAim3DModes.has(cfg.pattern) && !cfg.depth3d) window.setView3D?.(true);
      const result = previousStart.apply(this, arguments);
      $('#rangeOverlay')?.classList.add('hidden');
      if (!resume && waveModes.has(cfg.pattern)) setWaveTargets();
      if (cfg.pattern === 'flick-checkpoint') {
        checkpointDeadline = elapsed + 5;
        targets.forEach((target) => delete target.dsyDeadline);
        try { pending = false; checkpointPending = false; checkpointHits = 0; } catch { }
      }
      if (cfg.pattern === 'flick-exact-aim') {
        exactAimNext = 5.2;
        if (typeof exactCount === 'number') exactCount = Math.max(1, targets.length);
        targets.forEach((target) => { target.dsyBorn = now(); target.exactStart = target.dsyBorn; });
      }
      const timer = waveLabel();
      if (timer) timer.hidden = !waveModes.has(cfg.pattern);
      return result;
    };
  }

  const previousPause = window.pause;
  if (previousPause) {
    window.pause = function () {
      const wasPaused = !!paused;
      const result = previousPause.apply(this, arguments);
      if (!wasPaused && paused) pauseStartedAt = now();
      else if (wasPaused && !paused && pauseStartedAt) {
        if (waveDeadline) waveDeadline += now() - pauseStartedAt;
        pauseStartedAt = 0;
      }
      return result;
    };
  }

  const previousFinish = window.finish;
  if (previousFinish) {
    window.finish = function () {
      const result = previousFinish.apply(this, arguments);
      const timer = waveLabel();
      if (timer) timer.hidden = true;
      if (waveFailed) {
        $('#rangeOverlay').innerHTML = '<b>OLEADA FALLIDA</b><small>No alcanzaste a limpiar los cinco objetivos en cinco segundos.</small>';
        $('#sessionNote').textContent = 'Oleada fallida · vuelve a intentarlo';
      } else if (cfg.pattern === 'flick-40' || cfg.pattern === 'flick-40-shrink') {
        $('#rangeOverlay').innerHTML = '<b>40/40 · CAMPO DESPEJADO</b><small>Terminaste el ejercicio antes de que acabara el cronómetro.</small>';
      }
      return result;
    };
  }

  const previousFrame = window.frame;
  if (previousFrame) {
    window.frame = function (stamp) {
      const time = Number(stamp) || now();
      if (running && !paused && waveModes.has(cfg.pattern) && waveDeadline && time >= waveDeadline) {
        waveFailed = true;
        flickMisses++;
        playMissSound?.();
        window.finish?.();
        return;
      }
      const result = previousFrame.apply(this, arguments);
      if (running && !paused && cfg.pattern === 'flick-exact-aim') {
        const expired = targets.find((target) => !target.dead && Number.isFinite(target.dsyBorn) && time - target.dsyBorn >= 5200);
        if (expired) {
          flickMisses++; comboStreak = 0; playMissSound?.(); updateStreakHud?.();
          const replacement = newT(0); replacement.dsyBorn = time; replacement.exactStart = time; replacement.spawnAt = time;
          Object.assign(expired, replacement, { dead: false });
          targets = [expired]; exactAimNext = elapsed + 5.2;
          const note = $('#sessionNote'); if (note) note.textContent = 'FALLO · expiró el objetivo; aparece otro en el campo';
        }
      }
      const timer = waveLabel();
      if (timer) {
        timer.hidden = !running || paused || !waveModes.has(cfg.pattern);
        if (waveModes.has(cfg.pattern) && waveDeadline) {
          timer.textContent = `OLEADA ${waveNumber} · ${Math.max(0, (waveDeadline - time) / 1000).toFixed(1)} s`;
        }
      }
      return result;
    };
  }

  function updateModeCopy() {
    const desc = $('#modeDescription');
    const meta = $('.range .meta span:nth-child(2)');
    const english = document.body.dataset.language === 'en';
    if (cfg.pattern === 'flick-checkpoint') {
      if (desc) desc.textContent = english ? 'Five circles stay on the field. Aim and press E; clear all five within five seconds.' : 'Cinco círculos permanecen en el campo. Apunta y presiona E; limpia los cinco antes de que pasen cinco segundos.';
      if (meta) meta.textContent = english ? 'AIM AT A CIRCLE · PRESS E · 5 s PER WAVE' : 'APUNTA AL CÍRCULO · PRESIONA E · 5 s POR OLEADA';
    } else if (cfg.pattern === 'flick-exact-aim') {
      if (desc) desc.textContent = english ? 'One target grows, shrinks, then disappears. Hit it before it expires; a new one appears elsewhere.' : 'Un objetivo crece, se encoge y desaparece. Pégale antes de que expire; aparecerá otro en otro lugar.';
      if (meta) meta.textContent = english ? 'HIT BEFORE THE TARGET EXPIRES · 5.2 s' : 'GOLPEA ANTES DE QUE EXPIRE · 5.2 s';
    } else if (cfg.pattern === 'flick-40' || cfg.pattern === 'flick-40-shrink') {
      if (desc) desc.textContent = english ? 'Forty targets fill the field. Each hit makes the rest smaller; every hit target stays gone.' : 'Cuarenta objetivos llenan el campo. Cada impacto los reduce; cada objetivo desaparece para siempre.';
      if (meta) meta.textContent = english ? '40 TARGETS · THE LAST HIT ENDS THE DRILL' : '40 OBJETIVOS · EL ÚLTIMO IMPACTO TERMINA EL EJERCICIO';
    } else if (waveModes.has(cfg.pattern)) {
      if (desc) desc.textContent = english ? 'Clear five targets in five seconds. A new wave appears after the group is cleared.' : 'Limpia cinco objetivos antes de cinco segundos. Una oleada nueva aparece al despejar el grupo.';
      if (meta) meta.textContent = english ? '5 TARGETS · 5 SECONDS · CLEAR TO START THE NEXT WAVE' : '5 OBJETIVOS · 5 SEGUNDOS · SIGUIENTE OLEADA AL LIMPIAR';
    } else if (lineTrackingModes.has(cfg.pattern)) {
      const copy = modeCopy[cfg.pattern]?.[english ? 'en' : 'es'];
      if (copy && desc) desc.textContent = copy[1];
      if (meta) meta.textContent = english ? 'ONE STRAIGHT ROUTE · REVERSES AT THE EDGE' : 'UNA RUTA RECTA · CAMBIA DE SENTIDO EN EL BORDE';
    } else if (freeAim3DModes.has(cfg.pattern)) {
      const copy = modeCopy[cfg.pattern]?.[english ? 'en' : 'es'];
      if (copy && desc) desc.textContent = copy[1];
      if (meta) meta.textContent = english ? '3D ARENA · RIGHT-DRAG ROTATES CAMERA · FREE CURSOR' : 'ARENA 3D · CLIC DERECHO GIRA LA CÁMARA · CURSOR LIBRE';
    } else if (cfg.pattern === 'flick-straight') {
      const copy = modeCopy[cfg.pattern][english ? 'en' : 'es'];
      if (desc) desc.textContent = copy[1];
      if (meta) meta.textContent = english ? 'MOVING FLICK · STRAIGHT PATH' : 'FLICK MÓVIL · TRAYECTORIA LINEAL';
    }
  }

  function applyModeLanguage(language) {
    const locale = language === 'es' ? 'es' : 'en';
    for (const [id, copy] of Object.entries(modeCopy)) {
      const row = modes.find((item) => item[0] === id);
      if (row) { row[1] = copy[locale][0]; row[3] = copy[locale][1]; }
      const option = patternSelect?.querySelector(`option[value="${id}"]`);
      if (option) option.textContent = copy[locale][0];
    }
    drawModes?.();
    updateModeCopy();
    window.renderWelcome?.();
  }

  const previousSync = window.sync;
  if (previousSync) {
    window.sync = function () {
      if (cfg.pattern === 'tracking-straight') cfg.pattern = 'tracking-line-x';
      if (cfg.pattern === 'life-track-checkpoint') cfg.pattern = 'horizontal';
      const result = previousSync.apply(this, arguments);
      registerModes();
      if (patternSelect) patternSelect.value = cfg.pattern;
      cfg.backgroundColor = '#eeeeee';
      if ($('#backgroundColor')) $('#backgroundColor').value = '#eeeeee';
      document.documentElement.style.setProperty('--mint', '#777777');
      updateModeCopy();
      return result;
    };
  }

  function enter3DForMode(key) {
    if (!freeAim3DModes.has(key)) return;
    if (document.pointerLockElement === c) document.exitPointerLock?.();
    window.setView3D?.(true);
  }
  document.addEventListener('click', (event) => {
    const home = event.target.closest('#exerciseCards [data-key]');
    const picker = event.target.closest('#trainingPicker [data-mode-key]');
    const key = home?.dataset.key || picker?.dataset.modeKey;
    if (key?.includes('-custom-') && cfg.depth3d) window.setView3D?.(false);
    if (key) enter3DForMode(key);
  }, true);
  patternSelect?.addEventListener('change', () => enter3DForMode(cfg.pattern));

  // Checkpoint is keyboard-only: clear the five visible targets with E; no extra bank orb.
  document.addEventListener('keydown', (event) => {
    if (cfg.pattern !== 'flick-checkpoint' || !running || paused || event.repeat || event.key.toLowerCase() !== 'e') return;
    const tag = event.target?.tagName?.toLowerCase();
    if (['input', 'textarea', 'select'].includes(tag) || event.target?.isContentEditable) return;
    const rect = c.getBoundingClientRect();
    const locked = document.pointerLockElement === c;
    const mx = locked ? rect.width / 2 : mouse.x;
    const my = locked ? rect.height / 2 : mouse.y;
    const target = targets.find((item) => !item.dead && isTargetAt(item, mx, my));
    if (!target) return;
    event.preventDefault(); event.stopPropagation(); event.stopImmediatePropagation();
    try { pending = false; checkpointPending = false; } catch { }
    window.killTarget?.(target, 'checkpoint', { x: target.x, y: target.y });
    try { pending = false; checkpointPending = false; checkpointHits = 0; } catch { }
  }, true);

  document.addEventListener('mousedown', (event) => {
    if (cfg.pattern === 'flick-checkpoint' && event.target === c) {
      event.preventDefault(); event.stopPropagation(); event.stopImmediatePropagation();
    }
  }, true);

  // Build custom routes from a short recording that the trainer can replay.
  const homeHeading = $('.welcome-heading');
  if (homeHeading && !$('#customTrainingCreate')) {
    const createButton = document.createElement('button');
    createButton.id = 'customTrainingCreate'; createButton.type = 'button';
    createButton.className = 'custom-training-create'; createButton.textContent = '+ CREAR ENTRENAMIENTO';
    homeHeading.append(createButton);
  }
  const creator = document.createElement('div'); creator.id = 'customTrainingModal'; creator.className = 'custom-training-modal';
  creator.innerHTML = '<section class="custom-training-dialog" role="dialog" aria-modal="true" aria-labelledby="customTrainingTitle"><header><div><small>RUTAS PERSONALIZADAS</small><h2 id="customTrainingTitle">Crea tu entrenamiento</h2></div><button type="button" class="custom-training-close" aria-label="Cerrar">×</button></header><div class="custom-training-controls"><label>NOMBRE<input class="custom-training-name" maxlength="28" placeholder="Mi ruta"></label><label>TIPO<select class="custom-training-type"><option value="tracking">Tracking</option><option value="flick">Flick</option></select></label><label>DURACIÓN<select class="custom-training-duration"><option value="5">5 segundos</option><option value="10" selected>10 segundos</option><option value="15">15 segundos</option><option value="20">20 segundos</option><option value="30">30 segundos</option></select></label></div><p class="custom-training-help">Pulsa grabar y arrastra el objetivo por el campo. El aim trainer registrará la ruta para repetirla con variaciones de inicio, dirección y velocidad.</p><div class="custom-record-stage" aria-label="Campo de grabación"><span class="custom-record-target"></span><span class="custom-record-status">CAMPO VACÍO · ARRASTRA EL OBJETIVO</span></div><div class="custom-record-footer"><span class="custom-record-clock">LISTO</span><button type="button" class="custom-record-start">● GRABAR</button><button type="button" class="custom-record-save" disabled>GUARDAR ENTRENAMIENTO</button></div></section>';
  document.body.append(creator);
  const recordStage = creator.querySelector('.custom-record-stage'), recordTarget = creator.querySelector('.custom-record-target'), recordClock = creator.querySelector('.custom-record-clock');
  let recording = false, recordStarted = 0, recordSamples = [], recordInterval = 0, recordDuration = 10;
  const setRecordTarget = (clientX, clientY) => {
    const rect = recordStage.getBoundingClientRect();
    const x = Math.max(0.04, Math.min(0.96, (clientX - rect.left) / rect.width));
    const y = Math.max(0.08, Math.min(0.92, (clientY - rect.top) / rect.height));
    recordTarget.style.left = `${x * 100}%`; recordTarget.style.top = `${y * 100}%`;
    return { x, y };
  };
  const stopRecording = () => {
    if (!recording) return;
    recording = false; clearInterval(recordInterval); recordStage.classList.remove('is-recording');
    creator.querySelector('.custom-record-start').textContent = '● GRABAR OTRA VEZ';
    creator.querySelector('.custom-record-save').disabled = recordSamples.length < 2;
    recordClock.textContent = `RUTA LISTA · ${recordSamples.length} PUNTOS`;
  };
  creator.querySelector('.custom-record-start').addEventListener('click', () => {
    if (recording) { stopRecording(); return; }
    recordDuration = Number(creator.querySelector('.custom-training-duration').value) || 10;
    recordSamples = []; recordStarted = performance.now(); recording = true;
    recordStage.classList.add('is-recording'); creator.querySelector('.custom-record-save').disabled = true;
    creator.querySelector('.custom-record-start').textContent = '■ DETENER';
    const rect = recordStage.getBoundingClientRect();
    const initial = setRecordTarget(rect.left + rect.width / 2, rect.top + rect.height / 2);
    recordSamples.push({ t: 0, ...initial });
    clearInterval(recordInterval);
    recordInterval = setInterval(() => {
      if (!recording) return;
      const t = Math.min(recordDuration, (performance.now() - recordStarted) / 1000);
      const box = recordStage.getBoundingClientRect(), cx = parseFloat(recordTarget.style.left) / 100, cy = parseFloat(recordTarget.style.top) / 100;
      recordSamples.push({ t, x: cx, y: cy });
      recordClock.textContent = `GRABANDO · ${Math.max(0, recordDuration - t).toFixed(1)} s`;
      if (t >= recordDuration) stopRecording();
    }, 33);
  });
  creator.querySelector('.custom-record-stage').addEventListener('pointerdown', event => {
    if (!recording) return;
    event.preventDefault(); recordStage.setPointerCapture?.(event.pointerId); setRecordTarget(event.clientX, event.clientY);
  });
  creator.querySelector('.custom-record-stage').addEventListener('pointermove', event => {
    if (recording && event.buttons) setRecordTarget(event.clientX, event.clientY);
  });
  creator.querySelector('.custom-record-stage').addEventListener('pointerup', event => { try { recordStage.releasePointerCapture?.(event.pointerId); } catch { } });
  creator.querySelector('.custom-record-save').addEventListener('click', () => {
    const name = creator.querySelector('.custom-training-name').value.trim().slice(0, 28);
    if (!name || recordSamples.length < 2) { alert('Ponle nombre y graba una ruta antes de guardar.'); return; }
    const duration = Number(creator.querySelector('.custom-training-duration').value) || 10;
    const compact = recordSamples.filter((point, index) => index === 0 || index === recordSamples.length - 1 || index % 2 === 0).slice(0, 900).map(point => ({ t: Math.max(0, Math.min(duration, Number(point.t) || 0)), x: Math.max(0, Math.min(1, Number(point.x) || .5)), y: Math.max(0, Math.min(1, Number(point.y) || .5)) }));
    if (compact.length < 2) { alert('La ruta es demasiado corta; grábala de nuevo.'); return; }
    const item = { id: (globalThis.crypto?.randomUUID?.() || `${Date.now()}${Math.random().toString(36).slice(2, 8)}`).replace(/[^a-z0-9]/gi, '').slice(0, 24), name: name || 'Mi entrenamiento', type: creator.querySelector('.custom-training-type').value, duration, points: compact };
    customTrainings = [...customTrainings.filter(old => old.id !== item.id), item].slice(-30);
    localStorage.setItem('aoCustomTrainings', JSON.stringify(customTrainings)); registerCustomTraining(item);
    creator.classList.remove('open'); window.renderWelcome?.();
  });
  const closeCreator = () => { if (recording) stopRecording(); creator.classList.remove('open'); };
  creator.querySelector('.custom-training-close').addEventListener('click', closeCreator);
  creator.addEventListener('mousedown', event => { if (event.target === creator) closeCreator(); });
  $('#customTrainingCreate')?.addEventListener('click', () => { creator.classList.add('open'); creator.querySelector('.custom-training-name').focus(); });
  document.addEventListener('keydown', event => { if (event.key === 'Escape' && creator.classList.contains('open')) closeCreator(); });

  // Recompute the canvas backing store after the arena changes layout or becomes visible.
  if (typeof ResizeObserver !== 'undefined' && c) {
    let lastArenaSize = '';
    const arenaObserver = new ResizeObserver((entries) => {
      const box = entries[0]?.contentRect;
      if (!box || box.width < 40 || box.height < 40) return;
      const nextSize = `${Math.round(box.width)}x${Math.round(box.height)}`;
      if (nextSize === lastArenaSize) return;
      lastArenaSize = nextSize;
      resize?.();
      if (!running) requestAnimationFrame(() => window.frame?.(now()));
    });
    arenaObserver.observe(c);
  }

  // Restart cleanly when choosing a different exercise from either list.
  document.addEventListener('click', (event) => {
    if (!event.target.closest('#modeList button, #exerciseCards button, #exerciseCards [data-pattern], #exerciseCards .exercise-card')) return;
    const prior = cfg.pattern;
    setTimeout(() => {
      if (cfg.pattern !== prior) {
        reset?.(); resize?.(); sync?.();
        $('#rangeOverlay')?.classList.remove('hidden');
      }
    }, 0);
  }, true);
  patternSelect?.addEventListener('change', () => {
    if ($('#settingsModal')?.classList.contains('open')) return;
    setTimeout(() => { reset?.(); resize?.(); sync?.(); }, 0);
  });

  // Keep legacy rank accents neutral and remove any leftover bot/avatar panel from older saves.
  const neutralizeRank = () => {
    const card = $('#dsyHomeRank');
    const small = card?.querySelector('small');
    if (small) small.textContent = 'AIM OVERDRIVE · CLASIFICACIÓN';
    const bot = $('#dsyBot, #botPanel, .bot-avatar, .xbl41sx-bot, [data-player-bot]');
    bot?.remove();
  };
  neutralizeRank();
  window.addEventListener('load', neutralizeRank, { once: true });
  $('#languageToggle')?.addEventListener('click', () => {
    setTimeout(() => applyModeLanguage(localStorage.getItem('aoLanguage') || 'en'), 0);
  });
  applyModeLanguage(document.body.dataset.language || localStorage.getItem('aoLanguage') || 'en');
  window.renderWelcome?.();
  window.sync?.();
})();
