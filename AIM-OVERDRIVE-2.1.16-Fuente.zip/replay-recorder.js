/* Full-screen, low-overhead training replays. Video is encoded in one-second
   chunks, then streamed to the user-selected path after the session. */
(() => {
  'use strict';

  const $ = (selector) => document.querySelector(selector);
  const W = 1280, H = 720, MAX_BYTES = 180 * 1024 * 1024;
  const arena = $('#arena');
  if (!arena) return;

  const panel = document.createElement('section');
  panel.className = 'replay-panel';
  panel.id = 'replayPanel';
  panel.innerHTML = `
    <div class="replay-head">
      <div><small>SESSION REPLAY</small><h3>Repetición de entrenamiento</h3></div>
      <label class="replay-toggle"><input id="replayEnabled" type="checkbox"><span class="replay-switch"></span><span>GRABACIÓN AUTOMÁTICA</span></label>
    </div>
    <p id="replayStatus" class="replay-status" aria-live="polite">Replays activados · se grabará cada entrenamiento.</p>
    <div id="replaySummary" class="replay-summary" hidden></div>
    <video id="replayPreview" controls playsinline preload="metadata" hidden></video>
    <div id="replayActions" class="replay-actions" hidden>
      <button id="saveReplayButton" class="replay-primary">GUARDAR REPLAY</button>
      <button id="discardReplayButton">DESCARTAR</button>
    </div>`;
  $('.center .lower')?.after(panel);

  const status = $('#replayStatus'), toggle = $('#replayEnabled');
  const preview = $('#replayPreview'), summary = $('#replaySummary'), actions = $('#replayActions');
  const saveButton = $('#saveReplayButton'), discardButton = $('#discardReplayButton');
  const videoCanvas = document.createElement('canvas');
  videoCanvas.width = W; videoCanvas.height = H;
  const videoCtx = videoCanvas.getContext('2d', { alpha: false });
  let enabled = localStorage.getItem('aoReplayEnabled') !== 'false';
  let recorder = null, stream = null, parts = [], byteCount = 0, previewUrl = '';
  let currentEvents = [], reactionTimes = [], wasTracking = false, outsideSince = 0;
  let endStats = null, discardOnStop = false, capped = false, previousToast = null;
  let saving = false;
  toggle.checked = enabled;

  function setStatus(message, state = '') {
    status.textContent = message;
    status.dataset.state = state;
  }
  function clearPreview() {
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    previewUrl = '';
    preview.removeAttribute('src');
    preview.load();
    preview.hidden = true;
    summary.hidden = true;
    summary.replaceChildren();
    actions.hidden = true;
  }
  function formatTime(value) {
    const seconds = Math.max(0, Number(value) || 0);
    const mins = Math.floor(seconds / 60), secs = Math.floor(seconds % 60);
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  }
  function liveAccuracy() {
    const total = (Number(flickHits) || 0) + (Number(flickMisses) || 0);
    if (typeof isFlickMode === 'function' && isFlickMode()) return total ? flickHits / total * 100 : 0;
    return elapsed > 0 ? Math.min(100, tracking / elapsed * 100) : 0;
  }
  function liveMovement() {
    const seconds = Math.max(1, Number(elapsed) || 0);
    const width = Math.max(100, (range?.w || 500) * .22);
    return Math.min(100, (Number(mouseDistance) || 0) / seconds / width * 100);
  }
  function roundRect(ctx, x, y, w, h, r, color) {
    ctx.fillStyle = color; ctx.beginPath(); ctx.roundRect(x, y, w, h, r); ctx.fill();
  }
  function drawVideoFrame() {
    if (!recorder || recorder.state !== 'recording' || !videoCtx) return;
    const q = videoCtx, now = performance.now();
    q.fillStyle = '#101010'; q.fillRect(0, 0, W, H);
    const top = 72, bottom = 98, availW = W - 40, availH = H - top - bottom;
    const factor = Math.min(availW / Math.max(1, arena.width), availH / Math.max(1, arena.height));
    const dw = arena.width * factor, dh = arena.height * factor;
    const dx = (W - dw) / 2, dy = top + (availH - dh) / 2;
    q.drawImage(arena, dx, dy, dw, dh);
    q.fillStyle = '#101010'; q.fillRect(0, 0, W, top);
    q.fillStyle = '#f4f4f4'; q.font = '700 20px Arial, sans-serif';
    q.fillText('AIM OVERDRIVE  /  SESSION REPLAY', 24, 31);
    q.fillStyle = '#bdbdbd'; q.font = '13px Arial, sans-serif';
    q.fillText((($('#modeTitle')?.textContent || cfg.pattern || 'TRAINING').trim()).toUpperCase(), 24, 54);
    q.textAlign = 'right'; q.fillStyle = '#fff'; q.font = '700 17px Arial, sans-serif';
    q.fillText(`SCORE  ${typeof scoreValue === 'function' ? scoreValue() : 0}`, W - 24, 31);
    q.fillStyle = '#cfcfcf'; q.font = '13px Arial, sans-serif';
    q.fillText(`${formatTime(elapsed)}  ·  ${Math.round(liveAccuracy())}% ${isFlickMode?.() ? 'PRECISIÓN' : 'SEGUIMIENTO'}`, W - 24, 54);
    q.textAlign = 'left';

    const barY = H - bottom;
    q.fillStyle = '#101010'; q.fillRect(0, barY, W, bottom);
    q.fillStyle = '#575757'; q.fillRect(22, barY + 11, W - 44, 2);
    const sessionLimit = Math.max(1, Number(cfg.duration) || 100);
    const progress = Math.max(0, Math.min(1, (Number(elapsed) || 0) / sessionLimit));
    q.fillStyle = '#f2f2f2'; q.fillRect(22, barY + 10, (W - 44) * progress, 4);
    for (const event of currentEvents) {
      const eventProgress = Math.max(0, Math.min(1, event.at / Math.max(sessionLimit, elapsed || 1)));
      q.fillStyle = event.kind === 'hit' ? '#fff' : event.kind === 'miss' ? '#858585' : '#c8c8c8';
      q.fillRect(22 + (W - 44) * eventProgress - 1, barY + 7, 3, 10);
    }
    const stats = [
      ['TIEMPO', formatTime(elapsed)],
      ['MOVIMIENTO', `${Math.round(liveMovement())}/100`],
      ['REACCIÓN', reactionTimes.length ? `${Math.round(reactionTimes.reduce((a,b)=>a+b,0)/reactionTimes.length)} ms` : '—'],
      ['SEGUIMIENTO', `${Math.round(liveAccuracy())}%`]
    ];
    const cellW = (W - 44) / stats.length;
    stats.forEach(([label, value], i) => {
      const x = 22 + i * cellW;
      q.fillStyle = '#aaa'; q.font = '10px Arial, sans-serif'; q.fillText(label, x, barY + 38);
      q.fillStyle = '#fff'; q.font = '700 17px Arial, sans-serif'; q.fillText(value, x, barY + 63);
    });
    q.textAlign = 'right'; q.fillStyle = '#aaa'; q.font = '10px Arial, sans-serif';
    q.fillText('HIT  □    MISS  ■    TRACK  ─', W - 24, barY + 82); q.textAlign = 'left';

    if (previousToast && now - previousToast.at < 1250) {
      const age = now - previousToast.at, alpha = Math.max(0, 1 - age / 1250);
      const label = previousToast.kind === 'hit' ? `HIT  ·  ${formatTime(previousToast.atSeconds)}`
        : previousToast.kind === 'miss' ? `MISS  ·  ${formatTime(previousToast.atSeconds)}`
        : `TRACK REACQUIRED  ·  ${Math.round(previousToast.reactionMs || 0)} ms`;
      q.globalAlpha = alpha;
      roundRect(q, W - 300, top + 18, 274, 44, 9, '#121212');
      q.strokeStyle = '#eee'; q.lineWidth = 1; q.strokeRect(W - 300, top + 18, 274, 44);
      q.fillStyle = '#fff'; q.font = '700 14px Arial, sans-serif'; q.textAlign = 'right'; q.fillText(label, W - 40, top + 45); q.textAlign = 'left';
      q.globalAlpha = 1;
    }
  }
  window.captureReplayFrame = drawVideoFrame;

  function recordEvent(kind, details = {}) {
    if (!recorder || recorder.state !== 'recording') return;
    const event = { kind, at: Math.max(0, Number(elapsed) || 0), atMs: performance.now(), reactionMs: Math.max(0, Number(details.reactionMs) || 0) };
    currentEvents.push(event);
    if (currentEvents.length > 1600) currentEvents.shift();
    if (kind === 'hit' && event.reactionMs > 0) reactionTimes.push(event.reactionMs);
    previousToast = { ...event };
  }
  window.recordReplayEvent = recordEvent;

  document.addEventListener('mousedown', (event) => {
    if (!recorder || recorder.state !== 'recording' || !running || paused || event.button !== 0 || event.target !== arena) return;
    if (typeof isFlickMode !== 'function' || !isFlickMode() || cfg.pattern === 'flick-checkpoint' || cfg.pattern === 'flick-life' || (isComboMode?.() && comboPhase !== 'flick')) return;
    const rect = arena.getBoundingClientRect();
    const mx = document.pointerLockElement === arena ? rect.width / 2 : event.clientX - rect.left;
    const my = document.pointerLockElement === arena ? rect.height / 2 : event.clientY - rect.top;
    const hit = targets.some(target => isTargetAt(target, mx, my));
    if (!hit) recordEvent('miss');
  }, true);

  function updateTrackingEvents(now) {
    if (!recorder || recorder.state !== 'recording' || !running || paused) { wasTracking = false; return; }
    if (inside && !wasTracking) {
      const reactionMs = outsideSince ? Math.max(0, now - outsideSince) : 0;
      if (reactionMs > 70) recordEvent('track', { reactionMs });
      outsideSince = 0;
    } else if (!inside && wasTracking) outsideSince = now;
    wasTracking = !!inside;
  }

  function chooseMime() {
    const candidates = ['video/webm;codecs=vp8', 'video/webm'];
    return candidates.find(type => MediaRecorder.isTypeSupported(type)) || '';
  }
  function resetSessionReplayUi() {
    clearPreview(); parts = []; byteCount = 0; currentEvents = []; reactionTimes = [];
    endStats = null; capped = false; previousToast = null; wasTracking = false; outsideSince = 0;
    saveButton.disabled = false; saveButton.textContent = 'GUARDAR REPLAY';
  }
  function startCapture() {
    if (!enabled || !running) return;
    if (recorder) {
      if (recorder.state === 'inactive') setTimeout(startCapture, 50);
      return;
    }
    resetSessionReplayUi();
    if (typeof MediaRecorder === 'undefined' || !arena.captureStream || !videoCanvas.captureStream) {
      setStatus('Este equipo no dispone de grabación de video compatible.', 'error'); return;
    }
    try {
      const mimeType = chooseMime();
      stream = videoCanvas.captureStream(60);
      recorder = new MediaRecorder(stream, { ...(mimeType ? { mimeType } : {}), videoBitsPerSecond: 5_000_000 });
      discardOnStop = false;
      recorder.ondataavailable = (event) => {
        if (!event.data || !event.data.size || discardOnStop) return;
        byteCount += event.data.size;
        if (byteCount > MAX_BYTES) {
          capped = true;
          setStatus('Replay parcial · alcanzó el límite de 180 MB.', 'warning');
          if (recorder?.state === 'recording') recorder.stop();
          return;
        }
        parts.push(event.data);
      };
      recorder.onerror = () => setStatus('La grabación se interrumpió; el ejercicio puede continuar.', 'error');
      recorder.onstop = () => {
        stream?.getTracks().forEach(track => track.stop()); stream = null;
        recorder = null;
        if (discardOnStop) { resetSessionReplayUi(); setStatus(enabled ? 'Grabación descartada.' : 'Grabación automática desactivada.'); return; }
        if (!parts.length) { setStatus('No se generó video en esta sesión.', 'error'); return; }
        const blob = new Blob(parts, { type: 'video/webm' });
        previewUrl = URL.createObjectURL(blob);
        preview.src = previewUrl; preview.hidden = false;
        renderSummary(endStats || snapshotStats());
        actions.hidden = false;
        setStatus(capped ? 'Replay parcial listo para revisar o guardar.' : 'Replay listo · vista de campo a 60 fps.', 'ready');
        if (cfg.depth3d) requestAnimationFrame(() => panel.scrollIntoView({ behavior: 'smooth', block: 'center' }));
      };
      recorder.start(1000);
      setStatus('REC ● grabando a 60 fps · el campo sigue jugable.', 'recording');
    } catch (error) {
      recorder = null; stream?.getTracks().forEach(track => track.stop()); stream = null;
      setStatus('No se pudo iniciar el replay: ' + (error?.message || 'error de video'), 'error');
    }
  }
  window.startReplayCapture = startCapture;

  function snapshotStats() {
    const seconds = Math.max(0, Number(elapsed) || 0);
    const total = (Number(flickHits) || 0) + (Number(flickMisses) || 0);
    const accuracy = isFlickMode?.() ? (total ? flickHits / total * 100 : 0) : (seconds ? tracking / seconds * 100 : 0);
    const movement = liveMovement();
    const avgReaction = reactionTimes.length ? reactionTimes.reduce((sum, value) => sum + value, 0) / reactionTimes.length : 0;
    const reactionScore = reactionTimes.length ? Math.max(0, Math.min(100, 100 - avgReaction / 12)) : Math.min(100, (Number(switches) || 0) / Math.max(1, seconds) * 8);
    const trackingScore = isFlickMode?.() ? Math.min(100, total ? flickHits / total * 100 : 0) : Math.min(100, accuracy);
    const timingScore = Math.min(100, seconds / Math.max(1, Number(cfg.duration) || 100) * 100);
    return { seconds, accuracy, movement, avgReaction, reactionScore, trackingScore, timingScore, score: typeof scoreValue === 'function' ? scoreValue() : 0, hits: Number(flickHits) || 0, misses: Number(flickMisses) || 0, tracking: Number(tracking) || 0, best: Math.max(Number(best) || 0, Number(bestComboStreak) || 0), switches: Number(switches) || 0, pattern: cfg.pattern };
  }
  function renderSummary(data) {
    summary.replaceChildren(); summary.hidden = false;
    const overall = Math.round((data.timingScore + data.movement + data.reactionScore + data.trackingScore) / 4);
    const entries = [
      ['CALIFICACIÓN', `${overall}/100`], ['TIEMPO', formatTime(data.seconds)],
      ['MOVIMIENTO', `${Math.round(data.movement)}/100`],
      ['REACCIÓN', data.avgReaction ? `${Math.round(data.avgReaction)} ms · ${Math.round(data.reactionScore)}/100` : `${Math.round(data.reactionScore)}/100`],
      ['SEGUIMIENTO', `${Math.round(data.trackingScore)}%`],
      ['RACHA MÁXIMA', `${Number(data.best).toFixed(1)} s`],
      ['ACIERTOS / FALLOS', `${data.hits} / ${data.misses}`], ['PUNTAJE', `${data.score}`]
    ];
    for (const [label, value] of entries) {
      const card = document.createElement('div'); card.className = 'replay-metric';
      const title = document.createElement('small'); title.textContent = label;
      const text = document.createElement('b'); text.textContent = value;
      card.append(title, text); summary.append(card);
    }
  }

  function stopCapture() {
    if (cfg.depth3d) document.exitPointerLock?.();
    if (!recorder || recorder.state !== 'recording') return;
    endStats = snapshotStats();
    setStatus('Cerrando el video y preparando la repetición…', 'recording');
    recorder.stop();
  }
  window.stopReplayCapture = stopCapture;

  function cancelCapture() {
    if (recorder) {
      discardOnStop = true;
      if (recorder.state === 'recording') recorder.stop();
    } else resetSessionReplayUi();
  }
  window.cancelReplayCapture = cancelCapture;

  async function saveReplay() {
    if (saving || !parts.length) return;
    saving = true; saveButton.disabled = true; saveButton.textContent = 'GUARDANDO…';
    const date = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    const mode = String($('#modeTitle')?.textContent || cfg.pattern || 'training').trim().replace(/[^a-z0-9-_ ]/gi, '').replace(/\s+/g, '-');
    const filename = `Aim-Overdrive-${mode}-${date}.webm`;
    try {
      if (!window.replayNative) {
        const link = document.createElement('a'); link.href = previewUrl; link.download = filename; link.click();
      } else {
        const result = await window.replayNative.beginSave(filename);
        if (result.canceled) { saveButton.disabled = false; saveButton.textContent = 'GUARDAR REPLAY'; saving = false; return; }
        try {
          for (let i = 0; i < parts.length; i++) {
            await window.replayNative.writeChunk(await parts[i].arrayBuffer());
            setStatus(`Guardando replay… ${Math.round((i + 1) / parts.length * 100)}%`, 'recording');
          }
          const saved = await window.replayNative.finishSave();
          setStatus(`Replay guardado · ${saved.filePath}`, 'ready');
        } catch (error) { await window.replayNative.abortSave(); throw error; }
      }
      saveButton.textContent = 'REPLAY GUARDADO';
    } catch (error) {
      saveButton.disabled = false; saveButton.textContent = 'GUARDAR REPLAY';
      setStatus('No se pudo guardar: ' + (error?.message || 'error de archivo'), 'error');
    } finally { saving = false; }
  }

  toggle.addEventListener('change', () => {
    enabled = toggle.checked;
    localStorage.setItem('aoReplayEnabled', String(enabled));
    if (!enabled) { cancelCapture(); setStatus('Grabación automática desactivada.'); }
    else if (running && !paused) {
      const waitForOldRecorder = () => recorder ? setTimeout(waitForOldRecorder, 40) : startCapture();
      waitForOldRecorder();
    }
    else setStatus('Grabación activada · se grabará el siguiente entrenamiento.');
  });
  saveButton.addEventListener('click', saveReplay);
  discardButton.addEventListener('click', () => { clearPreview(); parts = []; byteCount = 0; setStatus(enabled ? 'Replay descartado · listo para el próximo entrenamiento.' : 'Replay descartado.'); });

  const oldPause = window.pause;
  if (oldPause) window.pause = function () {
    const wasPaused = !!paused;
    const result = oldPause.apply(this, arguments);
    if (!wasPaused && paused) recordEvent('pause');
    else if (wasPaused && !paused) recordEvent('resume');
    return result;
  };
  let lastFrameTime = 0;
  const trackingObserver = () => {
    const now = performance.now();
    if (now - lastFrameTime >= 1000 / 30) { updateTrackingEvents(now); lastFrameTime = now; }
    requestAnimationFrame(trackingObserver);
  };
  requestAnimationFrame(trackingObserver);
  if (enabled) setStatus('Replays activados · se grabará cada entrenamiento.');
  else setStatus('Grabación automática desactivada.');
})();
