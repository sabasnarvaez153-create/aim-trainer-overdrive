/* AIM OVERDRIVE 2.1.7 — two stable, cached 3D environments. */
(()=>{
 'use strict';
 const addFace=(mesh,points,color,edge)=>mesh.push({points,color,edge});
 function box(mesh,cx,cy,cz,sx,sy,sz,colors=['#454545','#303030','#292929','#222','#3b3b3b','#292929'],edge='#5a5a5a'){
  const x0=cx-sx/2,x1=cx+sx/2,y0=cy-sy/2,y1=cy+sy/2,z0=cz-sz/2,z1=cz+sz/2;
  const v=[[x0,y0,z0],[x1,y0,z0],[x1,y1,z0],[x0,y1,z0],[x0,y0,z1],[x1,y0,z1],[x1,y1,z1],[x0,y1,z1]];
  [[0,1,2,3],[4,7,6,5],[0,4,5,1],[3,2,6,7],[0,3,7,4],[1,5,6,2]].forEach((ids,i)=>addFace(mesh,ids.map(n=>v[n]),colors[i]||colors[0],edge));
 }
 function quad(mesh,a,b,c,d,color,edge){addFace(mesh,[a,b,c,d],color,edge)}
 function houseMesh(accent){
  const mesh=[],lo=-16,hi=16,bottom=-5,top=8,back=-20,front=20;
  // Empty room: exactly four flat walls, a flat floor and a flat ceiling.
  quad(mesh,[lo,bottom,back],[hi,bottom,back],[hi,bottom,front],[lo,bottom,front],'#303030',null);
  quad(mesh,[lo,top,front],[hi,top,front],[hi,top,back],[lo,top,back],'#252525',null);
  quad(mesh,[lo,bottom,back],[lo,bottom,front],[lo,top,front],[lo,top,back],'#292929',null);
  quad(mesh,[hi,bottom,front],[hi,bottom,back],[hi,top,back],[hi,top,front],'#252525',null);
  quad(mesh,[lo,bottom,back],[hi,bottom,back],[hi,top,back],[lo,top,back],'#303030',null);
  quad(mesh,[hi,bottom,front],[lo,bottom,front],[lo,top,front],[hi,top,front],hexAlpha('#343434',.16),null);
  return mesh;
 }
 function emptyMesh(accent){
  const mesh=[],floor=-5,extent=180;
  // A clean, solid floor stays stable at every camera angle and costs one polygon.
  quad(mesh,[-extent,floor,-extent],[extent,floor,-extent],[extent,floor,extent],[-extent,floor,extent],'#292929',null);
  return mesh;
 }
 function cameraPoint(point){
  const sy=Math.sin(cameraYaw),cy=Math.cos(cameraYaw),sp=Math.sin(cameraPitch),cp=Math.cos(cameraPitch);
  const side=point[0]*cy-point[2]*sy,depthFlat=point[0]*sy+point[2]*cy;
  return{x:side,y:point[1]*cp-depthFlat*sp,z:point[1]*sp+depthFlat*cp};
 }
 function clipNear(points,near=.55){
  const out=[];
  for(let i=0;i<points.length;i++){
   const current=points[i],previous=points[(i+points.length-1)%points.length],ci=current.z>=near,pi=previous.z>=near;
   if(ci!==pi){const t=(near-previous.z)/(current.z-previous.z);out.push({x:previous.x+(current.x-previous.x)*t,y:previous.y+(current.y-previous.y)*t,z:near})}
   if(ci)out.push(current);
  }
  return out;
 }
 let meshKey='',mesh=[];let imageKey='',sceneImage=null;
 function renderBackground(ctx,w,h,type,accent){
  const sky=ctx.createLinearGradient(0,0,0,h);sky.addColorStop(0,'#101010');sky.addColorStop(.48,'#292929');sky.addColorStop(1,'#090909');ctx.fillStyle=sky;ctx.fillRect(0,0,w,h);
  const focal=Math.min(w,h)*.94,distance=Math.max(.55,Math.min(1.7,(cfg.cameraDistance||100)/100)),faces=[];
  for(const face of mesh){
   const clipped=clipNear(face.points.map(cameraPoint));if(clipped.length<3)continue;
   const depth=clipped.reduce((sum,p)=>sum+p.z,0)/clipped.length;
   faces.push({face,depth,points:clipped.map(p=>({x:w/2+p.x*focal/(p.z*distance),y:h/2-p.y*focal/(p.z*distance)}))});
  }
  faces.sort((a,b)=>b.depth-a.depth);ctx.lineJoin='round';
  for(const item of faces){const points=item.points;ctx.beginPath();points.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath();ctx.fillStyle=item.face.color;ctx.fill();if(item.face.edge){ctx.strokeStyle=item.face.edge;ctx.lineWidth=.65;ctx.stroke()}}
  const vignette=ctx.createRadialGradient(w/2,h/2,Math.min(w,h)*.18,w/2,h/2,Math.max(w,h)*.74);vignette.addColorStop(0,'transparent');vignette.addColorStop(1,'rgba(0,0,0,.48)');ctx.fillStyle=vignette;ctx.fillRect(0,0,w,h);
  ctx.fillStyle='#eeeeee';ctx.font='700 9px Arial,sans-serif';ctx.fillText(type==='house'?'CASA · ENTRENAMIENTO 3D':'CAMPO ABIERTO · 3D',14,20);
  ctx.fillStyle='#bcbcbc';ctx.font='8px Arial,sans-serif';ctx.fillText('RATÓN GIRA · ESC LIBERA',14,34);
 }
 window.draw3DScene=function(now,w,h){
  const type=cfg.arena3d==='empty'?'empty':'house',accent=cfg.sceneColor||'#929292';
  const nextMeshKey=type+'|'+accent;if(nextMeshKey!==meshKey){mesh=type==='house'?houseMesh(accent):emptyMesh(accent);meshKey=nextMeshKey;imageKey=''}
  const yaw=Math.round(cameraYaw*1000)/1000,pitch=Math.round(cameraPitch*1000)/1000;
  const nextImageKey=[w,h,type,accent,yaw,pitch,cfg.cameraDistance||100].join('|');
  if(nextImageKey!==imageKey){
   if(!sceneImage)sceneImage=document.createElement('canvas');
   const width=Math.max(1,Math.ceil(w)),height=Math.max(1,Math.ceil(h));
   if(sceneImage.width!==width)sceneImage.width=width;if(sceneImage.height!==height)sceneImage.height=height;
   renderBackground(sceneImage.getContext('2d'),width,height,type,accent);imageKey=nextImageKey;
  }
  x.clearRect(0,0,w,h);x.drawImage(sceneImage,0,0,w,h);
 };
})();


