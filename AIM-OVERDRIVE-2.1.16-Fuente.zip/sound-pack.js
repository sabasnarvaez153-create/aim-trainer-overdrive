/* AIM OVERDRIVE 2.1.7 — fixed sound roles and a named, selectable Flick bank. */
(()=>{
 'use strict';
 const $=selector=>document.querySelector(selector);
 const manifest=window.AO_SOUND_MANIFEST||{};
 const baseUi=window.playUiCue,baseFlick=window.playFlickHit,baseTrack=window.playTargetHit;
 const baseStreak=window.playStreakSound,baseMiss=window.playMissSound;
 const baseTrackingSound=window.startTrackingSound,stopBaseTrackingSound=window.stopTrackingSound;
 const players=new Map();
 const packActive=()=>cfg.soundProfile!=='classic';
 const flickEntries=Array.isArray(manifest.flick)?manifest.flick:[];
 const flickByFile=new Map(flickEntries.map(entry=>[entry.file,entry]));
 const flickByLegacy=new Map(flickEntries.filter(entry=>entry.legacy).map(entry=>[entry.legacy,entry.file]));

 function volumeFor(kind){
  const master=(Number(cfg.soundMaster??100)/100)*(Number(cfg.soundPackVolume??100)/100);
  const category=kind==='ui'||kind==='interface'||kind==='hud'?Number(cfg.soundUiVolume??70)/100:
   kind==='streak'?Number(cfg.soundStreakVolume??100)/100:
   kind==='miss'?Number(cfg.soundMissVolume??100)/100:Number(cfg.soundHitVolume??100)/100;
  return Math.max(0,Math.min(1,master*category));
 }
 function playFile(file,kind='hit',force=false){
  if(!file)return false;
  const volume=volumeFor(kind);if(!force&&volume<=0)return true;
  let player=players.get(file);
  if(!player){player=new Audio(new URL('assets/sfx/selective/'+file,document.baseURI).href);player.preload='auto';players.set(file,player)}
  player.pause();player.currentTime=0;player.volume=force?Math.max(.12,volume||.65):volume;player.playbackRate=1;
  const result=player.play();if(result&&typeof result.catch==='function')result.catch(()=>{});return true;
 }
 function playRole(role,kind=role,force=false){return playFile(manifest[role],kind,force)}
 function selectedFlickFile(){
  const selected=String(cfg.hitSound||'');if(!selected.startsWith('pack:'))return '';
  const file=selected.slice(5);return flickByFile.has(file)?file:flickByLegacy.get(file)||'';
 }
 function addFlickOptions(){
  const select=$('#hitSound');if(!select)return;
  let group=select.querySelector('optgroup[data-sonidero-flick]');
  if(!group){group=document.createElement('optgroup');group.label='SONIDERO · FLICK ('+flickEntries.length+' sonidos)';group.dataset.sonideroFlick='true';
   flickEntries.forEach(entry=>{const option=document.createElement('option');option.value='pack:'+entry.file;option.textContent=entry.label;group.append(option)});select.append(group)}
  const picked=selectedFlickFile();if(picked)cfg.hitSound='pack:'+picked;
  select.value=cfg.hitSound||'arcade';if(!select.value)select.value='pack:'+(flickEntries[0]?.file||'');
 }
 function installSettings(){
  const lab=$('.sound-lab');if(!lab||$('#soundProfile'))return;
  const controls=document.createElement('div');controls.className='sound-pack-controls';
  controls.innerHTML='<label>PERFIL GENERAL<select id="soundProfile"><option value="sonidero">Sonidos fijos</option><option value="classic">Sonidos clásicos originales</option></select></label><label>VOLUMEN DEL PACK <span><input id="soundPackVolume" type="range" min="0" max="150" value="100"><b id="soundPackVolumeValue">100%</b></span></label><label>VOLUMEN DE INTERFAZ <span><input id="soundUiVolume" type="range" min="0" max="100" value="70"><b id="soundUiVolumeValue">70%</b></span></label><label class="sound-pack-toggle"><input id="soundUiEnabled" type="checkbox" checked> SONIDOS FIJOS DE UI / HUD</label><small class="sound-pack-note">Cada acción conserva su propio sonido. Flick usa uno de los 20 sonidos elegidos en el selector; nunca cambia al azar.</small><div class="sound-pack-previews"><small>ESCUCHAR</small><button type="button" data-sfx-preview="ui">UI</button><button type="button" data-sfx-preview="interface">INTERFAZ</button><button type="button" data-sfx-preview="hud">HUD</button><button type="button" data-sfx-preview="tracking">SEGUIMIENTO</button><button type="button" data-sfx-preview="flick">FLICK</button><button type="button" data-sfx-preview="elimination">ELIMINAR</button><button type="button" data-sfx-preview="streak">RACHA</button><button type="button" data-sfx-preview="miss">FALLO</button></div>';
  lab.insertBefore(controls,lab.firstChild);
  const profile=$('#soundProfile'),packVolume=$('#soundPackVolume'),uiVolume=$('#soundUiVolume'),uiEnabled=$('#soundUiEnabled');
  profile.value=cfg.soundProfile||'sonidero';packVolume.value=cfg.soundPackVolume??100;uiVolume.value=cfg.soundUiVolume??70;uiEnabled.checked=cfg.soundUiEnabled!==false;
  function readSettings(){cfg.soundProfile=profile.value;cfg.soundPackVolume=Number(packVolume.value);cfg.soundUiVolume=Number(uiVolume.value);cfg.soundUiEnabled=uiEnabled.checked;$('#soundPackVolumeValue').textContent=cfg.soundPackVolume+'%';$('#soundUiVolumeValue').textContent=cfg.soundUiVolume+'%';save()}
  [profile,packVolume,uiVolume,uiEnabled].forEach(el=>{el.addEventListener('input',readSettings);el.addEventListener('change',readSettings)});
 }
 addFlickOptions();installSettings();
 function reflectSettings(){
  const profile=$('#soundProfile'),packVolume=$('#soundPackVolume'),uiVolume=$('#soundUiVolume'),uiEnabled=$('#soundUiEnabled');
  if(profile)profile.value=cfg.soundProfile||'sonidero';if(packVolume)packVolume.value=cfg.soundPackVolume??100;if(uiVolume)uiVolume.value=cfg.soundUiVolume??70;if(uiEnabled)uiEnabled.checked=cfg.soundUiEnabled!==false;
  const packValue=$('#soundPackVolumeValue'),uiValue=$('#soundUiVolumeValue');if(packValue)packValue.textContent=(cfg.soundPackVolume??100)+'%';if(uiValue)uiValue.textContent=(cfg.soundUiVolume??70)+'%';
  const hitSelect=$('#hitSound');if(hitSelect){const picked=selectedFlickFile();hitSelect.value=picked?'pack:'+picked:(cfg.hitSound||'arcade');if(!hitSelect.value)hitSelect.value='pack:'+(flickEntries[0]?.file||'')}
 }
 const previousSync=window.sync;if(previousSync)window.sync=function(){const result=previousSync.apply(this,arguments);reflectSettings();return result};
 window.playInterfaceSound=function(){if(cfg.soundUiEnabled===false)return;if(packActive())return playRole('interface','interface');return baseUi?.call(this,'open')};
 window.playFixedUiSound=function(){if(cfg.soundUiEnabled===false)return;if(packActive())return playRole('ui','ui');return baseUi?.call(this,'open')};
 window.playUiCue=function(kind){
  if(cfg.soundUiEnabled===false)return;if(!packActive())return baseUi?.apply(this,arguments);
  if(kind==='finish'){if(cfg.soundStreak!==false)playRole('streak','streak');return}
  if(kind==='pause'){playRole('hud','hud');return}if(kind==='open'){playRole('interface','interface');return}playRole('ui','ui');
 };
 window.playFlickHit=function(){
  if(cfg.soundHits===false)return;
  if(typeof isFlickMode==='function'&&isFlickMode()){
   const picked=selectedFlickFile();if(packActive()&&picked){playFile(picked,'hit');return}
   return baseFlick?.apply(this,arguments);
  }
  if(packActive()){playRole('elimination','hit');return}return baseFlick?.apply(this,arguments);
 };
 window.playTargetHit=function(){if(packActive()){if(cfg.soundHits!==false)playRole('tracking','hit');return}return baseTrack?.apply(this,arguments)};
 window.playStreakSound=function(){if(packActive()){if(cfg.soundStreak!==false)playRole('streak','streak');return}return baseStreak?.apply(this,arguments)};
 window.playMissSound=function(){if(packActive()){if(cfg.soundMiss!==false)playRole('miss','miss');return}return baseMiss?.apply(this,arguments)};
 window.startTrackingSound=function(){if(!packActive())return baseTrackingSound?.apply(this,arguments)};
 window.stopTrackingSound=function(){return stopBaseTrackingSound?.apply(this,arguments)};
 document.addEventListener('click',event=>{if(cfg.soundUiEnabled===false||!packActive())return;const button=event.target.closest('button,[role=button],.exercise-card');if(!button||button.disabled||button.matches('#startBtn,[data-sfx-preview]'))return;if(button.matches('#classicHomeBtn,#classicSettingsBtn,#classicDrillsBtn,.exercise-card,.home-dock button,.picker-close,.picker-cancel,.settings-close,.settings-cancel,.settings-accept,[data-home-action]'))playRole('interface','interface');else if(button.matches('#view2d,#view3d')||button.closest('.settings-dialog,.training-picker,.settings-modal,.reticle-controls'))playRole('hud','hud');else playRole('ui','ui')},true);
 document.addEventListener('change',event=>{const control=event.target;if(!control.matches('input,select')||!control.closest('.settings-controls,.settings-dialog,.reticle-controls,.editor'))return;if(cfg.soundUiEnabled===false||!packActive())return;playRole('hud','hud')},true);
 window.playEliminationSound=function(){if(cfg.soundUiEnabled===false)return;if(packActive())return playRole('elimination','hit');return baseFlick?.call(this)};
 document.addEventListener('click',event=>{
  const preview=event.target.closest('[data-sfx-preview]');if(!preview)return;const role=preview.dataset.sfxPreview;
  if(role==='flick'){const picked=selectedFlickFile();if(picked)playFile(picked,'hit',true);else baseFlick?.call(window)}
  else playRole(role,role==='streak'?'streak':role==='miss'?'miss':role==='tracking'||role==='elimination'?'hit':'ui',true);
 });
})();
