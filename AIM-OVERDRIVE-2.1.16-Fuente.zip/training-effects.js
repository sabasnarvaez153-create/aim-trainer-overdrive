/* DSY training refresh: checkpoints, scalable drills, readable HUD and impact feedback. */
(()=>{
'use strict';
const $=s=>document.querySelector(s), now=()=>performance.now();
const addModes=[
 ['flick-40-shrink','Giant-to-Micro · 40','◉','Consigue 40 impactos; cada objetivo se hace más pequeño.']
];
addModes.forEach(m=>{if(!modes.some(q=>q[0]===m[0]))modes.push(m);if($('#patternSelect')&&!Array.from($('#patternSelect').options).some(o=>o.value===m[0]))$('#patternSelect').add(new Option(m[1],m[0]))});
if(cfg.pattern==='life-track-barriers'){cfg.pattern='reactive';if(typeof save==='function')save()}
let exactCount=1,checkpointHits=0,checkpointPending=false,scoreBonus=0,lastWave=0,particlePreset=localStorage.getItem('dsyParticlePreset')||'sparks';
const particles=[];
function resetCheckpointTargets(){targets=createSessionTargets();const stamp=now();targets.forEach(t=>{t.dsyDeadline=stamp+5000;t.dsyBorn=stamp});lastWave=stamp}
const baseTargetCount=window.targetCountForMode;
window.targetCountForMode=function(){
 if(cfg.pattern==='flick-checkpoint')return 5;
 if(cfg.pattern==='flick-exact-aim')return Math.max(1,Math.min(20,exactCount));
 if(cfg.pattern==='flick-40-shrink')return 1;
 return baseTargetCount.apply(this,arguments);
};
const baseDimensions=window.targetDimensions;
window.targetDimensions=function(t){
 const d=baseDimensions.apply(this,arguments);let scale=1;
 if(cfg.pattern==='flick-exact-aim'){
  const age=Math.max(0,(now()-(t.dsyBorn||t.spawnAt||now()))/2200),phase=age%1;
  scale=phase<.5?.24+.76*(phase/.5):1-.76*((phase-.5)/.5);
 }else if(cfg.pattern==='flick-40-shrink'){
  scale=Math.max(.46,2.45-(Math.max(0,flickHits)/39)*1.99);
 }
 if(scale===1)return d;
 return {rad:d.rad*scale,rx:d.rx*scale,ry:d.ry*scale,hitX:d.hitX*scale,hitY:d.hitY*scale};
};
const baseDrawTarget=window.drawGameTarget;
window.drawGameTarget=function(t){
 if(cfg.pattern==='flick-checkpoint'&&checkpointPending)return;
 if(t.dsySuppressUntil>now())return;
 const out=baseDrawTarget.apply(this,arguments);
 if(cfg.pattern==='flick-checkpoint'&&t.dsyDeadline){
  const left=Math.max(0,(t.dsyDeadline-now())/5000),d=targetDimensions(t),r=d.rad+8;
  x.save();x.lineWidth=3;x.strokeStyle=left<.3?'#7e7e7e':'#cccccc';x.globalAlpha=.8;x.beginPath();x.arc(t.x,t.y,r,-Math.PI/2,-Math.PI/2+Math.PI*2*left);x.stroke();
  x.font='8px var(--mono)';x.textAlign='center';x.fillStyle=left<.3?'#7e7e7e':'#f0f0f0';x.fillText(Math.ceil(left*5)+'s',t.x,t.y-r-5);x.restore();
 }
 return out;
};
const baseAt=window.isTargetAt;
window.isTargetAt=function(t,mx,my,d){
 if(cfg.pattern==='flick-checkpoint'&&checkpointPending)return false;
 return baseAt.apply(this,arguments);
};
function emitParticles(px,py,color){
 if(particlePreset==='none')return;
 const n=particlePreset==='confetti'?15:particlePreset==='soft'?7:11;
 for(let i=0;i<n;i++){
  const a=Math.PI*2*i/n+(Math.random()-.5)*.4,s=particlePreset==='soft'?25+Math.random()*30:55+Math.random()*125;
  particles.push({x:px,y:py,vx:Math.cos(a)*s,vy:Math.sin(a)*s,t:now(),life:particlePreset==='soft'?700:520,color,shape:particlePreset});
 }
}
function drawParticles(ts){
 const time=ts||now();
 for(let i=particles.length-1;i>=0;i--){
  const p=particles[i],age=(time-p.t)/p.life;if(age>=1){particles.splice(i,1);continue}
  const px=p.x+p.vx*age*.28,py=p.y+p.vy*age*.28;
  x.save();x.globalAlpha=1-age;x.strokeStyle=p.color;x.fillStyle=p.color;x.shadowColor=p.color;x.shadowBlur=7;
  if(p.shape==='rings'){x.lineWidth=2;x.beginPath();x.arc(p.x,p.y,6+age*32,0,Math.PI*2);x.stroke()}
  else if(p.shape==='confetti'){x.translate(px,py);x.rotate(age*8);x.fillRect(-2,-2,4,4)}
  else if(p.shape==='soft'){x.beginPath();x.arc(px,py,1.5+age*2,0,Math.PI*2);x.fill()}
  else{x.lineWidth=2;x.beginPath();x.moveTo(px,py);x.lineTo(px-p.vx*.045,py-p.vy*.045);x.stroke()}
  x.restore();
 }
}
function drawCheckpoint(ts){
 if(!checkpointPending)return;
 const w=c.clientWidth,h=c.clientHeight,p=cfg.depth3d?project3D(0,-.15,15,w,h):null,cx=p?.x??w*.5,cy=p?.y??h*.5,r=28+Math.sin(ts*.008)*2;
 x.save();const grad=x.createRadialGradient(cx-r*.35,cy-r*.38,2,cx,cy,r*1.4);grad.addColorStop(0,'#ffffff');grad.addColorStop(.28,'#d5d5d5');grad.addColorStop(.75,'#777777');grad.addColorStop(1,'#222222');
 x.fillStyle=grad;x.shadowColor='#bdbdbd';x.shadowBlur=28;x.beginPath();x.arc(cx,cy,r,0,Math.PI*2);x.fill();x.lineWidth=2;x.strokeStyle='#ffffff';x.stroke();
 x.shadowBlur=0;x.fillStyle='#222222';x.font='bold 9px var(--mono)';x.textAlign='center';x.fillText('CHECK',cx,cy-1);x.font='7px var(--mono)';x.fillText('CLICK TO BANK',cx,cy+10);x.restore();
 return {x:cx,y:cy,r};
}
const baseKill=window.killTarget;
window.killTarget=function(t,k,p){
 if(!t||t.dead)return;
 const oldX=t.x,oldY=t.y,oldWorld=t.world3D?{...t.world3D}:null,stamp=now(),modeAtHit=cfg.pattern;
 const oldDeathCount=deathMarks.length,oldFxCount=impactFx.length;
 const out=baseKill.apply(this,arguments);
 if(t.dead)return out;
 t.dsyBorn=stamp;t.dsySuppressUntil=stamp+42;
 const px=Number.isFinite(p?.x)?p.x:oldX,py=Number.isFinite(p?.y)?p.y:oldY;
 if(!cfg.depth3d&&k==='flick'){
  const mark=deathMarks[deathMarks.length-1];if(deathMarks.length>oldDeathCount&&mark){mark.x=px;mark.y=py}
  const fx=impactFx[impactFx.length-1];if(impactFx.length>oldFxCount&&fx){fx.x=px;fx.y=py}
 }
 emitParticles(px,py,cfg.targetColor||'#c5c5c5');
 if(modeAtHit==='flick-exact-aim'){
  exactCount=Math.min(20,exactCount+1);
  if(targets.length<exactCount){const extra=newT(targets.length);extra.dsyBorn=stamp;targets.push(extra)}
 }
 if(modeAtHit==='flick-40-shrink'&&flickHits>=40){
  setTimeout(()=>{if(cfg.pattern==='flick-40-shrink'&&running)finish()},0);
 }
 if(modeAtHit==='flick-checkpoint'){
  checkpointHits++;
  if(checkpointHits>=5){checkpointPending=true;targets.forEach(q=>{q.dsyCheckpointDone=true});const note=$('#sessionNote');if(note)note.textContent='Wave cleared — click the glowing checkpoint to bank your points.'}
  else{t.dsyDeadline=stamp+5000}
 }
 return out;
};
const baseDown=c.onmousedown;
c.onmousedown=function(e){
 if(cfg.pattern==='flick-checkpoint'&&running&&!paused){
  const rect=c.getBoundingClientRect(),mx=document.pointerLockElement===c?rect.width/2:e.clientX-rect.left,my=document.pointerLockElement===c?rect.height/2:e.clientY-rect.top;
  if(checkpointPending){
   const projected=cfg.depth3d?project3D(0,-.15,15,c.clientWidth,c.clientHeight):null,cx=projected?.x??c.clientWidth*.5,cy=projected?.y??c.clientHeight*.5;
   if(Math.hypot(mx-cx,my-cy)<58){e.preventDefault();checkpointPending=false;checkpointHits=0;scoreBonus+=125;const note=$('#sessionNote');if(note)note.textContent='Checkpoint banked · +125 points. Next wave ready.';resetCheckpointTargets();playStreakSound?.();return}
   return;
  }
 }
 return baseDown?.call(this,e);
};
const baseFrame=window.frame;
if(baseFrame)window.frame=function(ts){
 if(cfg.pattern==='flick-checkpoint'&&running&&!paused&&!checkpointPending){
  const stamp=now();
  if(targets.some(t=>!t.dead&&t.dsyDeadline&&stamp>=t.dsyDeadline)){
   flickMisses++;scoreBonus-=100;checkpointHits=0;resetCheckpointTargets();
   const note=$('#sessionNote');if(note)note.textContent='Checkpoint expired · −100 points. New wave ready.';
  }
 }
 const out=baseFrame.apply(this,arguments);
 return out;
};
const baseDrawFx=window.drawV206Effects;
window.drawV206Effects=function(ts){
 baseDrawFx?.apply(this,arguments);
 drawParticles(ts);drawCheckpoint(ts);
};
const baseDrawDeath=window.drawDeathMarks;
if(baseDrawDeath)window.drawDeathMarks=function(ts){baseDrawDeath.apply(this,arguments);drawParticles(ts)};
const base3d=window.draw3DScene;
if(base3d)window.draw3DScene=function(ts,w,h){
 const out=base3d.apply(this,arguments),time=ts||now(),type=cfg.arena3d||'grid';
 if(type==='nebula'||type==='reactor'||type==='ruins'){
  x.save();x.lineWidth=1.5;
  if(type==='nebula'){
   for(let band=0;band<4;band++){x.globalAlpha=.2;x.strokeStyle=['#cccccc','#a8a8a8','#eeeeee','#8c8c8c'][band];x.beginPath();for(let i=0;i<=90;i++){const xx=-11+i*.245,z=6+band*5,yy=1+Math.sin(i*.12+time*.0018+band)*(.35+band*.12),p=project3D(xx,yy,z,w,h);if(!p)continue;i?x.lineTo(p.x,p.y):x.moveTo(p.x,p.y)}x.stroke()}
  }else if(type==='reactor'){
   for(let ring=0;ring<6;ring++){const z=7+ring*4,rx=4+ring*.55,pts=[];for(let i=0;i<=56;i++){const a=i/56*Math.PI*2+time*.00025*(ring%2?1:-1),p=project3D(Math.cos(a)*rx,Math.sin(a)*rx*.55,z,w,h);if(p)pts.push(p)}if(pts.length>2){x.globalAlpha=.28+ring*.025;x.strokeStyle=ring%2?'#cccccc':'#888888';x.beginPath();pts.forEach((p,i)=>i?x.lineTo(p.x,p.y):x.moveTo(p.x,p.y));x.stroke()}}
  }else{
   for(let i=0;i<10;i++){const side=i%2?1:-1,z=7+Math.floor(i/2)*5,xx=side*(7+(i%3)*.55),top=3.2-(i%4)*.25,a=project3D(xx,-3.5,z,w,h),b=project3D(xx,top,z,w,h);if(a&&b){x.globalAlpha=.28;x.strokeStyle='#aaaaaa';x.lineWidth=3;x.beginPath();x.moveTo(a.x,a.y);x.lineTo(b.x,b.y);x.stroke();x.lineWidth=1;for(let k=0;k<4;k++){const q=project3D(xx+side*.35,top-k*.6,z,w,h);if(q){x.beginPath();x.arc(q.x,q.y,1.6,0,Math.PI*2);x.stroke()}}}}
  }
  x.restore();
 }
 return out;
};
const base2d=window.draw2DGrid;
if(base2d)window.draw2DGrid=function(){
 const out=base2d.apply(this,arguments),type=cfg.arena2d||'grid';
 if(type==='aurora'||type==='hex'){
  x.save();x.globalAlpha=.15;x.strokeStyle=cfg.sceneColor||'#929292';x.lineWidth=1;
  if(type==='aurora'){for(let k=0;k<7;k++){x.beginPath();for(let i=0;i<=100;i++){const xx=range.x+range.w*i/100,yy=range.y+range.h*(.2+k*.09)+Math.sin(i*.08+k+performance.now()*.001)*range.h*.035;i?x.lineTo(xx,yy):x.moveTo(xx,yy)}x.stroke()}}
  else{const sz=28;for(let yy=range.y;yy<range.y+range.h+sz;yy+=sz*.86)for(let xx=range.x;xx<range.x+range.w+sz;xx+=sz*1.5){x.beginPath();for(let i=0;i<6;i++){const a=Math.PI/3*i,px=xx+Math.cos(a)*sz*.55,py=yy+Math.sin(a)*sz*.55;i?x.lineTo(px,py):x.moveTo(px,py)}x.closePath();x.stroke()}}
  x.restore();
 }
 return out;
};
const baseMove=window.move;
if(baseMove)window.move=function(t,stamp,dt){
 const mode=cfg.pattern;
 return baseMove.apply(this,arguments);
};
const baseScore=window.scoreValue;
window.scoreValue=function(){return baseScore.apply(this,arguments)+scoreBonus};
const baseStart=window.start;
window.start=function(){
 exactCount=1;checkpointHits=0;checkpointPending=false;scoreBonus=0;particles.length=0;
 const out=baseStart.apply(this,arguments);
 targets.forEach(t=>{t.dsyBorn=now();if(cfg.pattern==='flick-checkpoint')t.dsyDeadline=now()+5000});
 return out;
};
const baseReset=window.reset;
if(baseReset)window.reset=function(){exactCount=1;checkpointHits=0;checkpointPending=false;scoreBonus=0;particles.length=0;return baseReset.apply(this,arguments)};
const baseSync=window.sync;
if(baseSync)window.sync=function(){const out=baseSync.apply(this,arguments);const d=$('#modeDescription');if(d&&cfg.pattern==='flick-checkpoint')d.textContent='Cinco objetivos por oleada. Tienes 5 s por objetivo; completa cinco impactos y pulsa el checkpoint para cobrar.';if(d&&cfg.pattern==='flick-40-shrink')d.textContent='Cuarenta impactos: el objetivo comienza enorme y se reduce con cada acierto.';return out};
const particleStyle=document.createElement('style');
particleStyle.textContent=
'body{--hud-accent:#c4c4c4}'+
'body.theme-standard{--hud-accent:#676767!important;--hud-panel:#fff!important;color:#222222!important}'+
'body.theme-standard header,body.theme-standard footer,body.theme-standard aside,body.theme-standard .stats>div,body.theme-standard .lower section,body.theme-standard .welcome-records,body.theme-standard #editorDeck{color:#252525!important}'+
'body.theme-standard .stats>div,body.theme-standard .lower section{box-shadow:0 8px 22px #25252512;border:1px solid #e4e4e4!important}'+
'body.theme-standard .stats>div{padding:14px 14px 13px;border-radius:12px!important}'+
'body.theme-standard .stats strong{color:#202020!important;font-size:25px!important}body.theme-standard .stats small,body.theme-standard .stats>div{color:#626262!important}'+
'body.theme-standard .heading h1,body.theme-standard .editor h2,body.theme-standard .brand,body.theme-standard .editor label{color:#252525!important}'+
'body.theme-standard .stats>div:first-child{background:linear-gradient(140deg,#fff,#f2f2f2)!important}'+
'body .streak-hud{--hud-accent:#c4c4c4!important;border-color:#c4c4c4!important;box-shadow:0 0 18px #c4c4c430!important}body .streak-hud b,body .streak-multiplier{color:#c4c4c4!important;text-shadow:0 0 16px #c4c4c466!important}'+
'body.theme-dashboard .streak-hud{--hud-accent:#dcdcdc!important}body.theme-handheld .streak-hud{--hud-accent:#c2c2c2!important}'+
'.dsy-home-rank{perspective:700px;transform-style:preserve-3d;transition:transform .3s,box-shadow .3s!important}.dsy-home-rank:hover{transform:rotateX(5deg) rotateY(-7deg) translateY(-3px)!important;box-shadow:0 18px 38px #25252525!important}.dsy-home-rank>b{display:grid;place-items:center;width:46px;height:46px;border-radius:50%;background:radial-gradient(circle at 35% 25%,#f7f7f7,#bbbbbb 35%,#6b6b6b 78%);color:#272727!important;text-shadow:0 2px 2px #fff88;box-shadow:inset 0 2px 5px #fff88,0 5px 10px #00033;transform:translateZ(14px)}'+
'.dsy-logo{display:block;width:52px;height:34px;object-fit:contain;mix-blend-mode:screen;filter:drop-shadow(0 0 5px #cacaca88)}body.theme-standard .dsy-logo{mix-blend-mode:multiply;filter:invert(1) drop-shadow(0 0 4px #67676744)}body.theme-dashboard .dsy-logo{filter:drop-shadow(0 0 5px #dfdfdfaa)}body.theme-handheld .dsy-logo{filter:drop-shadow(0 0 5px #a9a9a9aa)}.brand>b.logo-host,.DSY-mark.logo-host{display:flex;align-items:center;justify-content:center;padding:2px!important;border:0!important;background:transparent!important}'+
'.dsy-fold-toggle{display:flex;align-items:center;justify-content:space-between;width:100%;background:transparent;border:1px solid var(--hud-accent);color:var(--hud-accent);border-radius:6px;padding:8px 10px;font:700 9px var(--mono);cursor:pointer}.dsy-folded>*:not(.dsy-fold-toggle){display:none!important}.dsy-folded{min-height:40px!important;align-self:start!important}.dsy-fold-toggle:hover{filter:brightness(1.15);transform:translateY(-1px)}'+
'.dsy-particle-control{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:7px 0;color:var(--hud-accent);font:8px var(--mono)}.dsy-particle-control select{min-width:120px}'+
'.dsy-stat-badge{position:absolute;right:10px;top:8px;font:800 8px var(--mono);color:var(--hud-accent)}'+
'.dsy-loadout-shortcut{width:auto!important;min-width:92px;margin-left:8px}'+
'main:has(>aside:first-child.dsy-folded){grid-template-columns:42px minmax(0,1fr) 250px!important}main:has(>#editorDeck.dsy-folded){grid-template-columns:180px minmax(0,1fr) 48px!important}main:has(>aside:first-child.dsy-folded):has(>#editorDeck.dsy-folded){grid-template-columns:42px minmax(0,1fr) 48px!important}'+
'.theme-dashboard .saved-score-panel,.theme-dashboard .glory-panel{border-radius:2px!important;background:linear-gradient(135deg,#262626,#151515)!important;border-color:#aaaaaa!important}.theme-handheld .saved-score-panel,.theme-handheld .glory-panel{border-radius:20px!important;background:linear-gradient(145deg,#404040,#272727)!important;box-shadow:inset 0 1px #ffffff22,0 8px 20px #00044}.theme-standard .saved-score-panel,.theme-standard .glory-panel{border-radius:13px!important;background:linear-gradient(145deg,#fff,#f5f5f5)!important;border-color:#e0e0e0!important;color:#242424!important;box-shadow:0 8px 24px #29292910!important}'+
'@media(max-width:1150px){main{grid-template-columns:150px minmax(380px,1fr) 220px!important;gap:10px;padding:12px}.dsy-logo{width:44px}}'+
'@media(prefers-reduced-motion:reduce){.dsy-home-rank,.dsy-fold-toggle{transition:none!important}}';
document.head.append(particleStyle);
function installLogo(host){
 if(!host)return;
 host.classList.remove('logo-host');host.textContent='𖥸𖥔𖡼✪';
}
document.querySelectorAll('.DSY-mark').forEach(installLogo);
const mark=$('.v206-theme-mark');if(mark){mark.textContent='𖥸𖥔𖡼✪';mark.style.backgroundImage='none';mark.style.backgroundPosition='center';mark.style.backgroundRepeat='no-repeat';mark.style.backgroundSize='contain';mark.style.width='160px';mark.style.height='80px';mark.style.fontSize='48px'}
function collapseControl(host,label){
 if(!host||host.querySelector(':scope > .dsy-fold-toggle'))return;
 const b=document.createElement('button');b.type='button';b.className='dsy-fold-toggle';b.textContent=label+'  ▾';b.setAttribute('aria-expanded','true');
 host.insertBefore(b,host.firstChild);
 const key='dsy207-fold-'+label,closed=localStorage.getItem(key)==='1';host.classList.toggle('dsy-folded',closed);b.setAttribute('aria-expanded',String(!closed));b.textContent=label+(closed?'  ▸':'  ▾');
 b.addEventListener('click',()=>{const next=host.classList.toggle('dsy-folded');localStorage.setItem(key,next?'1':'0');b.setAttribute('aria-expanded',String(!next));b.textContent=label+(next?'  ▸':'  ▾')});
}
collapseControl($('#editorDeck'),'LOADOUT / SETTINGS');
const leftPanel=document.querySelector('main>aside:first-child');collapseControl(leftPanel,'DRILLS / RECORDS');
function addParticleControl(){
 const editor=$('#editorDeck');if(!editor||$('#dsyParticleStyle'))return;
 const label=document.createElement('label');label.className='dsy-particle-control';label.innerHTML='HIT PARTICLES <select id="dsyParticleStyle"><option value="sparks">DSY sparks</option><option value="rings">Shock rings</option><option value="confetti">Arc burst</option><option value="soft">Soft glow</option><option value="none">Off</option></select>';
 const sound=Array.from(editor.querySelectorAll('label')).find(e=>e.textContent.trim()==='SOUND LAB');
 editor.insertBefore(label,sound||editor.lastChild);
 const sel=$('#dsyParticleStyle');sel.value=particlePreset;sel.addEventListener('change',()=>{particlePreset=sel.value;localStorage.setItem('dsyParticlePreset',particlePreset)});
}
addParticleControl();
function addSceneOptions(){
 const a=$('#arena3d'),b=$('#arena2d');
 [['nebula','DSY Nebula'],['reactor','Core Reactor'],['ruins','Ancient Signal']].forEach(([v,n])=>{if(a&&!Array.from(a.options).some(o=>o.value===v))a.add(new Option(n,v))});
 [['aurora','Aurora Flow'],['hex','Hex Field']].forEach(([v,n])=>{if(b&&!Array.from(b.options).some(o=>o.value===v))b.add(new Option(n,v))});
}
addSceneOptions();
const head=$('header');
if(head){const btn=document.createElement('button');btn.className='dsy-fold-toggle dsy-loadout-shortcut';btn.textContent='⚙ LOADOUT';btn.onclick=()=>{const editor=$('#editorDeck');if(editor){editor.classList.remove('dsy-folded');const b=editor.querySelector(':scope > .dsy-fold-toggle');if(b){b.setAttribute('aria-expanded','true');b.textContent='LOADOUT / SETTINGS  ▾'}localStorage.setItem('dsy207-fold-LOADOUT / SETTINGS','0');editor.scrollIntoView({behavior:'smooth',block:'nearest'})}};head.append(btn)}
const origHit=window.playFlickHit;
function premiumHit(preset){
 if(!['steel','snap','thock','arc','ping'].includes(preset)||cfg.soundHits===false)return false;
 activeSoundCategory='hit';
 if(preset==='steel'){soundTone(125,.2,'triangle',.2,0,-88);soundTone(510,.13,'square',.085,.012,-250);soundTone(1180,.18,'sine',.055,.035,-460)}
 else if(preset==='snap'){soundTone(1420,.055,'sawtooth',.075,0,-880);soundTone(330,.1,'triangle',.12,.012,-170);soundTone(760,.075,'sine',.045,.045,-340)}
 else if(preset==='thock'){soundTone(82,.22,'sine',.22,0,-52);soundTone(210,.15,'triangle',.12,.01,-120);soundTone(470,.08,'square',.045,.025,-210)}
 else if(preset==='arc'){soundTone(245,.1,'sawtooth',.1,0,620);soundTone(740,.14,'triangle',.07,.025,-260);soundTone(1240,.11,'sine',.045,.06,-520)}
 else {soundTone(880,.09,'sine',.1,0,560);soundTone(1760,.17,'triangle',.045,.035,-380);soundTone(660,.13,'sine',.035,.07,-150)}
 activeSoundCategory='hit';return true;
}
window.playFlickHit=function(){
 const preset=cfg.hitSound||'arcade';
 if(premiumHit(preset))return;
 if(cfg.soundHits!==false&&preset==='dsy-impact'){soundTone(105,.16,'sawtooth',.17,0,-60);soundTone(420,.1,'triangle',.1,.018,320);soundTone(1120,.12,'sine',.06,.04,-440);return}
 if(cfg.soundHits!==false&&preset==='dsy-spark'){soundTone(740,.08,'triangle',.11,0,500);soundTone(1480,.13,'sine',.055,.025,-320);soundTone(2100,.08,'sine',.035,.07,-600);return}
 if(cfg.soundHits!==false&&preset==='dsy-wave'){soundTone(180,.19,'sine',.13,0,80);soundTone(560,.12,'triangle',.09,.025,180);soundTone(920,.18,'sine',.05,.06,-280);return}
 const out=origHit.apply(this,arguments),n=Math.min(8,Math.floor((+flickHits||0)/5));
 if(cfg.soundHits!==false){soundTone(360+n*42,.06,'triangle',.065,0,110+n*20);if(cfg.pattern==='flick-checkpoint'&&checkpointHits===4)soundTone(1046,.16,'sine',.07,.06,280)}
 return out;
};
const origTrackingHit=window.playTargetHit;
if(origTrackingHit)window.playTargetHit=function(){if(cfg.soundHits===false)return;const preset=cfg.hitSound||'arcade';if(premiumHit(preset))return;return origTrackingHit.apply(this,arguments)};
const hitSelect=$('#hitSound');
if(hitSelect)[['dsy-impact','DSY · Impact'],['dsy-spark','DSY · Spark'],['dsy-wave','DSY · Wave']].forEach(([v,n])=>{if(!Array.from(hitSelect.options).some(o=>o.value===v))hitSelect.add(new Option(n,v))});
const originalStartTrack=window.startTrackingSound,originalStopTrack=window.stopTrackingSound;let heldOsc=[];
window.startTrackingSound=function(){
 const out=originalStartTrack.apply(this,arguments);
 if(!heldOsc.length&&audioContext&&masterGain&&cfg.soundHits!==false){
  [[261.6,'sine',.012],[392,'triangle',.008]].forEach(([freq,type,vol])=>{const osc=audioContext.createOscillator(),gain=audioContext.createGain();osc.type=type;osc.frequency.value=freq;gain.gain.value=vol;osc.connect(gain);gain.connect(masterGain);osc.start();heldOsc.push({osc,gain})});
 }
 return out;
};
window.stopTrackingSound=function(){
 const out=originalStopTrack.apply(this,arguments);
 heldOsc.forEach(v=>{try{v.gain.gain.setTargetAtTime(.0001,audioContext.currentTime,.025);v.osc.stop(audioContext.currentTime+.12)}catch{}});heldOsc=[];
 return out;
};
if($('#patternSelect'))$('#patternSelect').addEventListener('change',()=>{exactCount=1;checkpointHits=0;checkpointPending=false;scoreBonus=0;particles.length=0});
try{sync?.();drawModes?.();renderWelcome?.()}catch{}
const title=$('title');if(title)title.textContent='AIM OVERDRIVE DSY — Training Lab 2.0.7';
document.querySelectorAll('.welcome-brand small').forEach(n=>n.textContent='TRAINING LAB · DSY · V2.0.7');
document.querySelectorAll('footer span').forEach(n=>{n.innerHTML=n.innerHTML.replace('2.0.6','2.0.7')});
})();


